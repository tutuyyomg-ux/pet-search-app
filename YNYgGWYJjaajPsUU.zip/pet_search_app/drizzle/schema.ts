import { boolean, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Pet cases table for lost/found/adoption posts
 */
export const cases = mysqlTable("cases", {
  id: int("id").autoincrement().primaryKey(),
  // 案件類型：遺失/拾獲/認養
  type: mysqlEnum("type", ["lost", "found", "adoption"]).notNull(),
  // 寵物資訊
  petName: varchar("petName", { length: 100 }),
  petType: varchar("petType", { length: 50 }),
  breed: varchar("breed", { length: 100 }),
  // 案件內容
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  // 圖片（S3 key）
  imageKey: varchar("imageKey", { length: 500 }),
  imageUrl: varchar("imageUrl", { length: 500 }),
  // 聯絡資訊
  contactName: varchar("contactName", { length: 100 }),
  contactPhone: varchar("contactPhone", { length: 30 }),
  // 狀態
  isUrgent: boolean("isUrgent").default(false).notNull(),
  isResolved: boolean("isResolved").default(false).notNull(),
  // 發布者（可匿名，不強制登入）
  authorName: varchar("authorName", { length: 100 }),
  authorOpenId: varchar("authorOpenId", { length: 64 }),
  // 統計
  views: int("views").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Case = typeof cases.$inferSelect;
export type InsertCase = typeof cases.$inferInsert;
