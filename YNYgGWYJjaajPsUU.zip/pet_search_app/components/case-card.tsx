import { View, Text, TouchableOpacity, StyleSheet, Image } from "react-native";
import { useRouter } from "expo-router";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { type PetCase, type CaseType } from "@/lib/storage";

const TYPE_LABEL: Record<CaseType, string> = { lost: "遺失", found: "拾獲", adoption: "認養" };
const TYPE_COLOR: Record<CaseType, string> = { lost: "#EF4444", found: "#3B82F6", adoption: "#10B981" };
const TYPE_BG: Record<CaseType, string> = { lost: "#FEE2E2", found: "#DBEAFE", adoption: "#D1FAE5" };

function timeAgo(iso: string): string {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return "剛剛";
  if (diff < 3600) return `${Math.floor(diff / 60)} 分鐘前`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小時前`;
  if (diff < 86400 * 30) return `${Math.floor(diff / 86400)} 天前`;
  if (diff < 86400 * 365) return `${Math.floor(diff / (86400 * 30))} 個月前`;
  return `${Math.floor(diff / (86400 * 365))} 年前`;
}

interface CaseCardProps {
  item: PetCase;
}

export function CaseCard({ item }: CaseCardProps) {
  const router = useRouter();

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={() => router.push({ pathname: "/case-detail", params: { id: item.id } })}
      activeOpacity={0.8}
    >
      {/* 左側圖片縮圖 */}
      <View style={styles.imageContainer}>
        {item.imageUri ? (
          <Image source={{ uri: item.imageUri }} style={styles.image} resizeMode="cover" />
        ) : (
          <View style={styles.imagePlaceholder}>
            <Text style={styles.placeholderIcon}>🐾</Text>
          </View>
        )}
        {item.isUrgent && (
          <View style={styles.urgentBadge}>
            <Text style={styles.urgentText}>緊急</Text>
          </View>
        )}
      </View>

      {/* 右側文字資訊 */}
      <View style={styles.content}>
        {/* 類型標籤 + 時間 */}
        <View style={styles.headerRow}>
          <View style={[styles.typeBadge, { backgroundColor: TYPE_BG[item.type] }]}>
            <Text style={[styles.typeText, { color: TYPE_COLOR[item.type] }]}>{TYPE_LABEL[item.type]}</Text>
          </View>
          <Text style={styles.time}>{timeAgo(item.createdAt)}</Text>
        </View>

        {/* 寵物名稱 */}
        <Text style={styles.petName} numberOfLines={1}>
          {item.petName || "未命名"}{item.breed ? ` · ${item.breed}` : ""}
        </Text>

        {/* 描述 */}
        {item.description ? (
          <Text style={styles.desc} numberOfLines={2}>{item.description}</Text>
        ) : null}

        {/* 地點 + 瀏覽數 */}
        <View style={styles.footerRow}>
          <View style={styles.infoRow}>
            <IconSymbol name="location.fill" size={11} color="#64748B" />
            <Text style={styles.infoText} numberOfLines={1}>{item.location || "未知地點"}</Text>
          </View>
          <View style={styles.viewsRow}>
            <IconSymbol name="eye" size={11} color="#9CA3AF" />
            <Text style={styles.viewsText}>{item.views ?? 0}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    flexDirection: "row",
    minHeight: 110,
  },
  imageContainer: {
    width: 110,
    position: "relative",
  },
  image: {
    width: 110,
    height: "100%",
  },
  imagePlaceholder: {
    width: 110,
    height: "100%",
    minHeight: 110,
    backgroundColor: "#E0E7FF",
    alignItems: "center",
    justifyContent: "center",
  },
  placeholderIcon: { fontSize: 32 },
  urgentBadge: {
    position: "absolute",
    top: 6,
    left: 6,
    backgroundColor: "#EF4444",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 5,
  },
  urgentText: { color: "#fff", fontSize: 10, fontWeight: "700" },
  content: {
    flex: 1,
    padding: 10,
    gap: 3,
    justifyContent: "space-between",
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  typeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
  },
  typeText: { fontSize: 11, fontWeight: "700" },
  time: { fontSize: 11, color: "#9CA3AF" },
  petName: { fontSize: 15, fontWeight: "700", color: "#1E293B" },
  desc: { fontSize: 12, color: "#6B7280", lineHeight: 17 },
  footerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 2,
  },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 3, flex: 1 },
  infoText: { fontSize: 11, color: "#64748B", flex: 1 },
  viewsRow: { flexDirection: "row", alignItems: "center", gap: 3 },
  viewsText: { fontSize: 11, color: "#9CA3AF" },
});
