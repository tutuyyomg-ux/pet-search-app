import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "list.bullet": "list",
  "plus.circle.fill": "add-circle",
  "heart.fill": "favorite",
  "heart": "favorite-border",
  "gearshape.fill": "settings",
  "magnifyingglass": "search",
  "bell.fill": "notifications",
  "person.fill": "person",
  "pawprint.fill": "pets",
  "location.fill": "location-on",
  "phone.fill": "phone",
  "camera.fill": "camera-alt",
  "photo.fill": "photo",
  "xmark": "close",
  "checkmark": "check",
  "exclamationmark.triangle.fill": "warning",
  "info.circle.fill": "info",
  "star.fill": "star",
  "map.fill": "map",
  "chart.bar.fill": "bar-chart",
  "square.and.arrow.up": "share",
  "trash.fill": "delete",
  "pencil": "edit",
  "arrow.left": "arrow-back",
  "eye.fill": "visibility",
  "clock.fill": "access-time",
  "plus": "add",
  "doc.text": "description",
  "xmark.circle.fill": "cancel",
  "people.fill": "group",
  "bubble.left.fill": "chat-bubble",
} as unknown as IconMapping;

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
