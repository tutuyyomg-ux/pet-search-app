export declare const themeColors: {
  primary: { light: string; dark: string };
  secondary: { light: string; dark: string };
  background: { light: string; dark: string };
  surface: { light: string; dark: string };
  foreground: { light: string; dark: string };
  muted: { light: string; dark: string };
  border: { light: string; dark: string };
  success: { light: string; dark: string };
  warning: { light: string; dark: string };
  error: { light: string; dark: string };
  tint: { light: string; dark: string };
  navBg: { light: string; dark: string };
  cardBg: { light: string; dark: string };
  tagLost: { light: string; dark: string };
  tagFound: { light: string; dark: string };
  tagAdopt: { light: string; dark: string };
};
