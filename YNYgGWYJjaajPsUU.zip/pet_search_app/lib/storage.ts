/**
 * 純本地儲存層 - 使用 AsyncStorage，無需後端
 */
import AsyncStorage from "@react-native-async-storage/async-storage";

export type CaseType = "lost" | "found" | "adoption";

export interface PetCase {
  id: string;
  type: CaseType;
  petName: string;
  petType: string;
  breed: string;
  color: string;
  location: string;
  description: string;
  contactName: string;
  contactPhone: string;
  imageUri?: string;
  isUrgent: boolean;
  createdAt: string;
  views: number;
}

const CASES_KEY = "pet_cases_v2";
const FAVORITES_KEY = "pet_favorites_v2";

// 預設示範資料
const DEFAULT_CASES: PetCase[] = [
  {
    id: "demo-1",
    type: "lost",
    petName: "小白",
    petType: "狗",
    breed: "柴犬",
    color: "白色",
    location: "台北市大安區",
    description: "2歲柴犬，白色毛髮，頸部有藍色項圈，非常親人，於大安森林公園附近走失，如有發現請聯絡。",
    contactName: "王小明",
    contactPhone: "0912-345-678",
    imageUri: undefined,
    isUrgent: true,
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    views: 42,
  },
  {
    id: "demo-2",
    type: "found",
    petName: "未知",
    petType: "貓",
    breed: "橘貓",
    color: "橘色",
    location: "新北市板橋區",
    description: "在板橋車站附近撿到一隻橘色公貓，約1歲，已帶至動物醫院確認無晶片，暫時代養中，請失主認領。",
    contactName: "李美華",
    contactPhone: "0923-456-789",
    imageUri: undefined,
    isUrgent: false,
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    views: 28,
  },
  {
    id: "demo-3",
    type: "adoption",
    petName: "豆豆",
    petType: "狗",
    breed: "米克斯",
    color: "黑白",
    location: "台中市西屯區",
    description: "3歲米克斯母狗，已結紮、施打疫苗，個性溫順，與小孩相處良好，因主人移居海外急需找新家，希望有愛心家庭收養。",
    contactName: "陳志豪",
    contactPhone: "0934-567-890",
    imageUri: undefined,
    isUrgent: false,
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    views: 65,
  },
];

// 讀取所有案件
export async function getCases(): Promise<PetCase[]> {
  try {
    const raw = await AsyncStorage.getItem(CASES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
    // 第一次使用，寫入示範資料
    await AsyncStorage.setItem(CASES_KEY, JSON.stringify(DEFAULT_CASES));
    return DEFAULT_CASES;
  } catch {
    return DEFAULT_CASES;
  }
}

// 新增案件
export async function addCase(newCase: Omit<PetCase, "id" | "createdAt" | "views">): Promise<PetCase> {
  const caseWithMeta: PetCase = {
    ...newCase,
    id: `case-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    createdAt: new Date().toISOString(),
    views: 0,
  };
  try {
    const current = await getCases();
    const updated = [caseWithMeta, ...current];
    await AsyncStorage.setItem(CASES_KEY, JSON.stringify(updated));
  } catch {
    // 靜默失敗
  }
  return caseWithMeta;
}

// 取得單一案件
export async function getCaseById(id: string): Promise<PetCase | null> {
  try {
    const cases = await getCases();
    return cases.find((c) => c.id === id) ?? null;
  } catch {
    return null;
  }
}

// 增加瀏覽次數
export async function incrementViews(id: string): Promise<void> {
  try {
    const cases = await getCases();
    const updated = cases.map((c) => (c.id === id ? { ...c, views: c.views + 1 } : c));
    await AsyncStorage.setItem(CASES_KEY, JSON.stringify(updated));
  } catch {
    // 靜默失敗
  }
}

// 讀取收藏 ID 列表
export async function getFavoriteIds(): Promise<string[]> {
  try {
    const raw = await AsyncStorage.getItem(FAVORITES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

// 切換收藏狀態
export async function toggleFavorite(id: string): Promise<boolean> {
  try {
    const ids = await getFavoriteIds();
    const isFav = ids.includes(id);
    const updated = isFav ? ids.filter((i) => i !== id) : [...ids, id];
    await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    return !isFav;
  } catch {
    return false;
  }
}

// 取得收藏案件列表
export async function getFavoriteCases(): Promise<PetCase[]> {
  try {
    const [ids, cases] = await Promise.all([getFavoriteIds(), getCases()]);
    return cases.filter((c) => ids.includes(c.id));
  } catch {
    return [];
  }
}

// 取得統計數字
export async function getStats(): Promise<{ lost: number; found: number; adoption: number; total: number }> {
  try {
    const cases = await getCases();
    return {
      lost: cases.filter((c) => c.type === "lost").length,
      found: cases.filter((c) => c.type === "found").length,
      adoption: cases.filter((c) => c.type === "adoption").length,
      total: cases.length,
    };
  } catch {
    return { lost: 0, found: 0, adoption: 0, total: 0 };
  }
}
