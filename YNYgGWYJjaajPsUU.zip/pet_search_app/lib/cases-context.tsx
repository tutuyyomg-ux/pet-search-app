import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { Platform } from 'react-native';

const FAVORITES_KEY = 'pet_search_favorites';

// 安全的 storage 包裝 — 避免原生模組未就緒時崩潰
const safeStorage = {
  async getItem(key: string): Promise<string | null> {
    try {
      if (Platform.OS === 'web') {
        return typeof localStorage !== 'undefined' ? localStorage.getItem(key) : null;
      }
      // 動態 import 避免在模組初始化時就崩潰
      const AsyncStorage = (await import('@react-native-async-storage/async-storage')).default;
      if (!AsyncStorage || typeof AsyncStorage.getItem !== 'function') return null;
      return await AsyncStorage.getItem(key);
    } catch {
      return null;
    }
  },
  async setItem(key: string, value: string): Promise<void> {
    try {
      if (Platform.OS === 'web') {
        if (typeof localStorage !== 'undefined') localStorage.setItem(key, value);
        return;
      }
      const AsyncStorage = (await import('@react-native-async-storage/async-storage')).default;
      if (!AsyncStorage || typeof AsyncStorage.setItem !== 'function') return;
      await AsyncStorage.setItem(key, value);
    } catch {
      // 靜默失敗，保持 in-memory 狀態
    }
  },
};

interface CasesContextType {
  favorites: number[];
  toggleFavorite: (id: number) => void;
  isFavorited: (id: number) => boolean;
}

const CasesContext = createContext<CasesContextType | undefined>(undefined);

export function CasesProvider({ children }: { children: React.ReactNode }) {
  const [favorites, setFavorites] = useState<number[]>([]);

  // 從 storage 載入收藏（完全非同步，不阻塞啟動）
  useEffect(() => {
    let mounted = true;
    safeStorage.getItem(FAVORITES_KEY).then((val) => {
      if (!mounted || !val) return;
      try {
        const parsed = JSON.parse(val);
        if (Array.isArray(parsed)) {
          setFavorites(parsed);
        }
      } catch {
        // 解析失敗時保持空陣列
      }
    });
    return () => { mounted = false; };
  }, []);

  const toggleFavorite = useCallback((id: number) => {
    setFavorites((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      // 非同步儲存，不阻塞 UI
      safeStorage.setItem(FAVORITES_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const isFavorited = useCallback(
    (id: number) => favorites.includes(id),
    [favorites]
  );

  return (
    <CasesContext.Provider value={{ favorites, toggleFavorite, isFavorited }}>
      {children}
    </CasesContext.Provider>
  );
}

export function useCases() {
  const ctx = useContext(CasesContext);
  if (!ctx) throw new Error('useCases must be used within CasesProvider');
  return ctx;
}
