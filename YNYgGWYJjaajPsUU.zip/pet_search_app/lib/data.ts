export type CaseType = 'lost' | 'found' | 'adopt';

export interface PetCase {
  id: string;
  type: CaseType;
  petName: string;
  petType: string;
  breed: string;
  color: string;
  location: string;
  date: string;
  description: string;
  imageUrl: string;
  contactName: string;
  contactPhone: string;
  isUrgent: boolean;
  isFavorited: boolean;
  views: number;
}

export const MOCK_CASES: PetCase[] = [
  {
    id: '1',
    type: 'lost',
    petName: '小白',
    petType: '狗',
    breed: '柴犬',
    color: '白色',
    location: '台北市大安區',
    date: '2026-06-25',
    description: '小白是一隻白色柴犬，約2歲，脖子上有藍色項圈，在大安公園附近走失，如有看到請聯絡我們。',
    imageUrl: 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400',
    contactName: '王小明',
    contactPhone: '0912-345-678',
    isUrgent: true,
    isFavorited: false,
    views: 128,
  },
  {
    id: '2',
    type: 'found',
    petName: '橘貓',
    petType: '貓',
    breed: '橘貓',
    color: '橘色',
    location: '新北市板橋區',
    date: '2026-06-26',
    description: '在板橋車站附近撿到一隻橘色貓咪，看起來很親人，身上無項圈，目前暫時收留中。',
    imageUrl: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400',
    contactName: '李美玲',
    contactPhone: '0923-456-789',
    isUrgent: false,
    isFavorited: true,
    views: 89,
  },
  {
    id: '3',
    type: 'adopt',
    petName: '豆豆',
    petType: '狗',
    breed: '米克斯',
    color: '棕色',
    location: '台中市西屯區',
    date: '2026-06-20',
    description: '豆豆是一隻溫馴可愛的米克斯，約3歲，已結紮施打疫苗，尋找有愛心的家庭領養。',
    imageUrl: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400',
    contactName: '陳志豪',
    contactPhone: '0934-567-890',
    isUrgent: false,
    isFavorited: false,
    views: 256,
  },
  {
    id: '4',
    type: 'lost',
    petName: '咪咪',
    petType: '貓',
    breed: '英國短毛貓',
    color: '灰色',
    location: '台北市信義區',
    date: '2026-06-27',
    description: '咪咪是一隻灰色英短，約1歲，非常怕生，在信義區附近走失，請幫忙留意。',
    imageUrl: 'https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=400',
    contactName: '張雅婷',
    contactPhone: '0945-678-901',
    isUrgent: true,
    isFavorited: false,
    views: 312,
  },
  {
    id: '5',
    type: 'found',
    petName: '黑狗',
    petType: '狗',
    breed: '拉布拉多',
    color: '黑色',
    location: '高雄市前鎮區',
    date: '2026-06-24',
    description: '在前鎮區撿到一隻黑色拉布拉多，體型中等，非常友善，有戴項圈但無名牌。',
    imageUrl: 'https://images.unsplash.com/photo-1611003229186-e0a7c7e3f8e9?w=400',
    contactName: '林俊賢',
    contactPhone: '0956-789-012',
    isUrgent: false,
    isFavorited: false,
    views: 67,
  },
  {
    id: '6',
    type: 'adopt',
    petName: '花花',
    petType: '貓',
    breed: '三花貓',
    color: '三花',
    location: '台南市東區',
    date: '2026-06-18',
    description: '花花是一隻三花貓，約5歲，個性溫和，已絕育，需要一個溫暖的家。',
    imageUrl: 'https://images.unsplash.com/photo-1495360010541-f48722b34f7d?w=400',
    contactName: '吳淑芬',
    contactPhone: '0967-890-123',
    isUrgent: false,
    isFavorited: true,
    views: 189,
  },
];

export const CASE_TYPE_LABELS: Record<CaseType, string> = {
  lost: '遺失',
  found: '拾獲',
  adopt: '認養',
};

export const CASE_TYPE_COLORS: Record<CaseType, { bg: string; text: string }> = {
  lost: { bg: '#FEE2E2', text: '#DC2626' },
  found: { bg: '#D1FAE5', text: '#059669' },
  adopt: { bg: '#FEF3C7', text: '#D97706' },
};
