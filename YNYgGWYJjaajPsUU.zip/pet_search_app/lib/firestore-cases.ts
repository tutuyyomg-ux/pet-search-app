/**
 * Firestore 案件資料層
 * 所有案件資料存入 Firebase Firestore，支援跨裝置同步
 * 圖片以 Base64 形式存入 Firestore（避免 Storage 限制）
 */
import {
  collection,
  addDoc,
  getDocs,
  getDoc,
  doc,
  query,
  orderBy,
  limit,
  serverTimestamp,
  updateDoc,
  increment,
  Timestamp,
  where,
  startAfter,
  QueryDocumentSnapshot,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import AsyncStorage from "@react-native-async-storage/async-storage";

export type CaseType = "lost" | "found" | "adoption" | "emergency";

export interface PetCase {
  id: string;
  type: CaseType;
  petName: string;
  petType: string;
  breed: string;
  color: string;
  location: string;
  description: string;
  contactName: string;
  contactPhone: string;
  imageBase64?: string; // Base64 圖片（存 Firestore）
  imageUri?: string;    // 本地 URI（相容舊資料）
  isUrgent: boolean;
  createdAt: string;    // ISO 字串（統一格式）
  views: number;
  resolved: boolean;    // 是否已解決
  resolvedAt?: string;  // 解決時間 ISO
  incidentDate?: string; // 走失/事發時間 ISO（選填）
}

const FAVORITES_KEY = "pet_favorites_v2";
const CASES_COLLECTION = "cases";

// ─── 案件讀取 ───────────────────────────────────────────────────

/** 讀取所有案件（最新 200 筆，依時間倒序） */
export async function getCases(): Promise<PetCase[]> {
  try {
    const q = query(
      collection(db, CASES_COLLECTION),
      orderBy("createdAt", "desc"),
      limit(200)
    );
    const snap = await getDocs(q);
    return snap.docs.map(docToCase);
  } catch (err) {
    console.error("[Firestore] getCases 失敗:", err);
    return [];
  }
}

/** 讀取單一案件 */
export async function getCaseById(id: string): Promise<PetCase | null> {
  try {
    const snap = await getDoc(doc(db, CASES_COLLECTION, id));
    if (!snap.exists()) return null;
    return docToCase(snap);
  } catch (err) {
    console.error("[Firestore] getCaseById 失敗:", err);
    return null;
  }
}

/** 取得統計數字 */
export async function getStats(): Promise<{ lost: number; found: number; adoption: number; emergency: number; total: number }> {
  try {
    const cases = await getCases();
    return {
      lost: cases.filter((c) => c.type === "lost").length,
      found: cases.filter((c) => c.type === "found").length,
      adoption: cases.filter((c) => c.type === "adoption").length,
      emergency: cases.filter((c) => c.type === "emergency").length,
      total: cases.length,
    };
  } catch {
    return { lost: 0, found: 0, adoption: 0, emergency: 0, total: 0 };
  }
}

// ─── 案件新增 ───────────────────────────────────────────────────

/** 新增案件至 Firestore */
export async function addCase(
  newCase: Omit<PetCase, "id" | "createdAt" | "views">
): Promise<PetCase> {
  const now = new Date().toISOString();
  const data = {
    type: newCase.type,
    petName: newCase.petName || "未命名",
    petType: newCase.petType || "",
    breed: newCase.breed || "",
    color: newCase.color || "",
    location: newCase.location || "",
    description: newCase.description || "",
    contactName: newCase.contactName || "",
    contactPhone: newCase.contactPhone || "",
    imageBase64: newCase.imageBase64 ?? "",
    imageUri: newCase.imageUri ?? "",
    isUrgent: newCase.isUrgent ?? false,
    incidentDate: newCase.incidentDate ?? null,
    resolved: false,
    resolvedAt: null,
    createdAt: serverTimestamp(),
    createdAtISO: now,
    views: 0,
  };

  const ref = await addDoc(collection(db, CASES_COLLECTION), data);

  return {
    id: ref.id,
    type: newCase.type,
    petName: data.petName,
    petType: data.petType,
    breed: data.breed,
    color: data.color,
    location: data.location,
    description: data.description,
    contactName: data.contactName,
    contactPhone: data.contactPhone,
    imageBase64: data.imageBase64,
    imageUri: data.imageUri,
    isUrgent: data.isUrgent,
    createdAt: now,
    views: 0,
    resolved: false,
    resolvedAt: undefined,
    incidentDate: newCase.incidentDate ?? undefined,
  };
}

// ─── 瀏覽次數 ───────────────────────────────────────────────────

/** 增加瀏覽次數 */
/** 更新案件內容 */
export async function updateCase(
  id: string,
  updates: Partial<Omit<PetCase, "id" | "createdAt" | "views">>
): Promise<void> {
  const data: Record<string, unknown> = { ...updates };
  // 移除 undefined 值，避免 Firestore 報錯
  Object.keys(data).forEach((k) => { if (data[k] === undefined) delete data[k]; });
  await updateDoc(doc(db, CASES_COLLECTION, id), data);
}

/** 刪除案件 */
export async function deleteCase(id: string): Promise<void> {
  const { deleteDoc } = await import("firebase/firestore");
  await deleteDoc(doc(db, CASES_COLLECTION, id));
}

/** 標記案件為已解決（可復原） */
export async function resolveCase(id: string, resolved: boolean): Promise<void> {
  const now = new Date().toISOString();
  await updateDoc(doc(db, CASES_COLLECTION, id), {
    resolved,
    resolvedAt: resolved ? now : null,
  });
}

export async function incrementViews(id: string): Promise<void> {
  try {
    await updateDoc(doc(db, CASES_COLLECTION, id), {
      views: increment(1),
    });
  } catch {
    // 靜默失敗（不影響 UX）
  }
}

// ─── 收藏（仍用 AsyncStorage 存 ID） ───────────────────────────

export async function getFavoriteIds(): Promise<string[]> {
  try {
    const raw = await AsyncStorage.getItem(FAVORITES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export async function toggleFavorite(id: string): Promise<boolean> {
  try {
    const ids = await getFavoriteIds();
    const isFav = ids.includes(id);
    const updated = isFav ? ids.filter((i) => i !== id) : [...ids, id];
    await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    return !isFav;
  } catch {
    return false;
  }
}

export async function getFavoriteCases(): Promise<PetCase[]> {
  try {
    const ids = await getFavoriteIds();
    if (ids.length === 0) return [];
    const cases = await getCases();
    return cases.filter((c) => ids.includes(c.id));
  } catch {
    return [];
  }
}

// ─── 工具函式 ───────────────────────────────────────────────────

function docToCase(snap: QueryDocumentSnapshot): PetCase {
  const d = snap.data();
  // createdAt 可能是 Firestore Timestamp 或 ISO 字串
  let createdAt = d.createdAtISO ?? d.createdAt;
  if (createdAt instanceof Timestamp) {
    createdAt = createdAt.toDate().toISOString();
  } else if (typeof createdAt !== "string") {
    createdAt = new Date().toISOString();
  }
  return {
    id: snap.id,
    type: d.type ?? "lost",
    petName: d.petName ?? "",
    petType: d.petType ?? "",
    breed: d.breed ?? "",
    color: d.color ?? "",
    location: d.location ?? "",
    description: d.description ?? "",
    contactName: d.contactName ?? "",
    contactPhone: d.contactPhone ?? "",
    imageBase64: d.imageBase64 ?? "",
    imageUri: d.imageUri ?? "",
    isUrgent: d.isUrgent ?? false,
    createdAt,
    views: d.views ?? 0,
    resolved: d.resolved ?? false,
    resolvedAt: d.resolvedAt ?? undefined,
    incidentDate: d.incidentDate ?? undefined,
  };
}
