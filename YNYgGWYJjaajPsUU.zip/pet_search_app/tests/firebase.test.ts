import { describe, it, expect } from "vitest";

// Test that Firebase config env vars are set
describe("Firebase Config", () => {
  it("should have all required Firebase environment variables set", () => {
    const requiredVars = [
      "EXPO_PUBLIC_FIREBASE_API_KEY",
      "EXPO_PUBLIC_FIREBASE_PROJECT_ID",
      "EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET",
      "EXPO_PUBLIC_FIREBASE_APP_ID",
    ];

    for (const varName of requiredVars) {
      const value = process.env[varName];
      expect(value, `${varName} should be set`).toBeTruthy();
      expect(value?.length, `${varName} should not be empty`).toBeGreaterThan(0);
    }
  });

  it("should have valid Firebase project ID format", () => {
    const projectId = process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID;
    expect(projectId).toBe("pet-search-cb2c3");
  });
});
