import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { storagePut } from "./storage";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Cases ────────────────────────────────────────────────────────────────
  cases: router({
    // 取得案件列表（公開）
    list: publicProcedure
      .input(
        z.object({
          type: z.enum(["lost", "found", "adoption"]).optional(),
          search: z.string().optional(),
          limit: z.number().min(1).max(100).default(50),
          offset: z.number().min(0).default(0),
        }).optional()
      )
      .query(async ({ input }) => {
        return db.getCases(input);
      }),

    // 取得單一案件（公開）
    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        await db.incrementCaseViews(input.id);
        return db.getCaseById(input.id);
      }),

    // 取得統計數字（公開）
    stats: publicProcedure.query(async () => {
      return db.getCasesCount();
    }),

    // 發布案件（公開，不需登入）
    create: publicProcedure
      .input(
        z.object({
          type: z.enum(["lost", "found", "adoption"]),
          petName: z.string().max(100).optional(),
          petType: z.string().max(50).optional(),
          breed: z.string().max(100).optional(),
          title: z.string().min(1).max(255),
          description: z.string().min(1).max(2000),
          location: z.string().min(1).max(255),
          imageKey: z.string().optional(),
          imageUrl: z.string().optional(),
          contactName: z.string().max(100).optional(),
          contactPhone: z.string().max(30).optional(),
          isUrgent: z.boolean().default(false),
          authorName: z.string().max(100).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const id = await db.createCase({
          ...input,
          authorOpenId: ctx.user?.openId ?? null,
          authorName: input.authorName ?? ctx.user?.name ?? "匿名用戶",
        });
        return { id };
      }),

    // 標記案件已解決（公開）
    resolve: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.markCaseResolved(input.id);
        return { success: true };
      }),
  }),

  // ─── 圖片上傳 ─────────────────────────────────────────────────────────────
  storage: router({
    // 上傳圖片：接收 base64，存到 S3，回傳 URL
    uploadImage: publicProcedure
      .input(
        z.object({
          base64: z.string(), // base64 encoded image
          mimeType: z.string().default("image/jpeg"),
          fileName: z.string().default("pet-photo.jpg"),
        })
      )
      .mutation(async ({ input }) => {
        // 解碼 base64
        const base64Data = input.base64.replace(/^data:image\/\w+;base64,/, "");
        const buffer = Buffer.from(base64Data, "base64");

        const key = `cases/${Date.now()}-${input.fileName}`;
        const { url } = await storagePut(key, buffer, input.mimeType);

        return { key, url };
      }),
  }),
});

export type AppRouter = typeof appRouter;
