import { desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { Case, InsertCase, InsertUser, cases, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ─── Cases ───────────────────────────────────────────────────────────────────

export async function getCases(opts?: {
  type?: "lost" | "found" | "adoption";
  search?: string;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db
    .select()
    .from(cases)
    .where(eq(cases.isResolved, false))
    .orderBy(desc(cases.isUrgent), desc(cases.createdAt))
    .limit(opts?.limit ?? 50)
    .offset(opts?.offset ?? 0);

  // Note: drizzle-orm mysql2 doesn't support dynamic where chaining easily,
  // so we fetch and filter in JS for search/type filtering
  const results = await db
    .select()
    .from(cases)
    .orderBy(desc(cases.isUrgent), desc(cases.createdAt))
    .limit(200);

  let filtered = results.filter((c) => !c.isResolved);

  if (opts?.type) {
    filtered = filtered.filter((c) => c.type === opts.type);
  }

  if (opts?.search) {
    const s = opts.search.toLowerCase();
    filtered = filtered.filter(
      (c) =>
        c.title.toLowerCase().includes(s) ||
        c.description.toLowerCase().includes(s) ||
        c.location.toLowerCase().includes(s) ||
        (c.petName && c.petName.toLowerCase().includes(s)) ||
        (c.breed && c.breed.toLowerCase().includes(s))
    );
  }

  return filtered.slice(opts?.offset ?? 0, (opts?.offset ?? 0) + (opts?.limit ?? 50));
}

export async function getCaseById(id: number): Promise<Case | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(cases).where(eq(cases.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createCase(data: InsertCase): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(cases).values(data);
  return (result as any).insertId as number;
}

export async function incrementCaseViews(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.update(cases).set({ views: sql`${cases.views} + 1` }).where(eq(cases.id, id));
}

export async function markCaseResolved(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(cases).set({ isResolved: true }).where(eq(cases.id, id));
}

export async function deleteCase(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(cases).where(eq(cases.id, id));
}

export async function getCasesCount(): Promise<{ lost: number; found: number; adoption: number; total: number }> {
  const db = await getDb();
  if (!db) return { lost: 0, found: 0, adoption: 0, total: 0 };

  const all = await db.select().from(cases).where(eq(cases.isResolved, false));
  const lost = all.filter((c) => c.type === "lost").length;
  const found = all.filter((c) => c.type === "found").length;
  const adoption = all.filter((c) => c.type === "adoption").length;
  return { lost, found, adoption, total: all.length };
}
