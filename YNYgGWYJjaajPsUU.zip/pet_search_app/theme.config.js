/** @type {const} */
const themeColors = {
  primary: { light: '#1A56DB', dark: '#3B82F6' },
  secondary: { light: '#F97316', dark: '#FB923C' },
  background: { light: '#F0F4FF', dark: '#0F172A' },
  surface: { light: '#FFFFFF', dark: '#1E293B' },
  foreground: { light: '#1E293B', dark: '#F1F5F9' },
  muted: { light: '#64748B', dark: '#94A3B8' },
  border: { light: '#CBD5E1', dark: '#334155' },
  success: { light: '#10B981', dark: '#34D399' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
  tint: { light: '#1A56DB', dark: '#3B82F6' },
  navBg: { light: '#1A56DB', dark: '#1E3A8A' },
  cardBg: { light: '#FFFFFF', dark: '#1E293B' },
  tagLost: { light: '#FEE2E2', dark: '#7F1D1D' },
  tagFound: { light: '#D1FAE5', dark: '#064E3B' },
  tagAdopt: { light: '#FEF3C7', dark: '#78350F' },
};

module.exports = { themeColors };
