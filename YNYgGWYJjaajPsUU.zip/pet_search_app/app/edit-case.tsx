"use client";
import { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
  Switch,
  Platform,
  Image,
  Modal,
  ActivityIndicator,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import {
  getCaseById,
  updateCase,
  type CaseType,
  type PetCase,
} from "@/lib/firestore-cases";
import * as ImagePicker from "expo-image-picker";
import * as ImageManipulator from "expo-image-manipulator";

const TYPES: { key: CaseType; label: string; icon: string; color: string; bg: string }[] = [
  { key: "lost", label: "遺失", icon: "🐾", color: "#EF4444", bg: "#FEE2E2" },
  { key: "found", label: "拾獲", icon: "🤝", color: "#3B82F6", bg: "#DBEAFE" },
  { key: "adoption", label: "認養", icon: "💗", color: "#10B981", bg: "#D1FAE5" },
  { key: "emergency", label: "緊急救護", icon: "🚨", color: "#F97316", bg: "#FFEDD5" },
];

// ─── 行事曆元件 ───────────────────────────────────────────────────
function CalendarPicker({
  visible,
  selectedDate,
  onSelect,
  onClose,
  title,
}: {
  visible: boolean;
  selectedDate: Date | null;
  onSelect: (date: Date) => void;
  onClose: () => void;
  title: string;
}) {
  const today = new Date();
  const [viewYear, setViewYear] = useState(selectedDate?.getFullYear() ?? today.getFullYear());
  const [viewMonth, setViewMonth] = useState(selectedDate?.getMonth() ?? today.getMonth());

  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const firstDayOfWeek = new Date(viewYear, viewMonth, 1).getDay();
  const WEEKDAYS = ["日", "一", "二", "三", "四", "五", "六"];

  const prevMonth = () => {
    if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1); }
    else setViewMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1); }
    else setViewMonth(m => m + 1);
  };

  const isSelected = (day: number) =>
    selectedDate &&
    selectedDate.getFullYear() === viewYear &&
    selectedDate.getMonth() === viewMonth &&
    selectedDate.getDate() === day;

  const isToday = (day: number) =>
    today.getFullYear() === viewYear &&
    today.getMonth() === viewMonth &&
    today.getDate() === day;

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDayOfWeek; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableOpacity style={cal.overlay} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} style={cal.container}>
          <Text style={cal.title}>{title}</Text>
          <View style={cal.nav}>
            <TouchableOpacity onPress={prevMonth} style={cal.navBtn}>
              <Text style={cal.navArrow}>‹</Text>
            </TouchableOpacity>
            <Text style={cal.navLabel}>{viewYear} 年 {viewMonth + 1} 月</Text>
            <TouchableOpacity onPress={nextMonth} style={cal.navBtn}>
              <Text style={cal.navArrow}>›</Text>
            </TouchableOpacity>
          </View>
          <View style={cal.weekRow}>
            {WEEKDAYS.map(w => <Text key={w} style={cal.weekDay}>{w}</Text>)}
          </View>
          <View style={cal.grid}>
            {cells.map((day, idx) => {
              const isFuture = day !== null && new Date(viewYear, viewMonth, day) > today;
              return (
                <TouchableOpacity
                  key={idx}
                  style={[cal.cell, day !== null && isSelected(day) && cal.cellSelected, day !== null && isToday(day) && !isSelected(day) && cal.cellToday]}
                  onPress={() => {
                    if (day !== null && !isFuture) onSelect(new Date(viewYear, viewMonth, day));
                  }}
                  disabled={day === null || isFuture}
                  activeOpacity={0.7}
                >
                  {day !== null && (
                    <Text style={[
                      cal.cellText,
                      isSelected(day) && cal.cellTextSelected,
                      isFuture && cal.cellTextFuture,
                      isToday(day) && !isSelected(day) && cal.cellTextToday,
                    ]}>{day}</Text>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
          <View style={cal.quickRow}>
            <TouchableOpacity style={cal.quickBtn} onPress={() => onSelect(today)}>
              <Text style={cal.quickText}>今天</Text>
            </TouchableOpacity>
            <TouchableOpacity style={cal.quickBtn} onPress={() => onSelect(new Date(today.getTime() - 86400000 * 7))}>
              <Text style={cal.quickText}>一週前</Text>
            </TouchableOpacity>
            <TouchableOpacity style={cal.quickBtn} onPress={() => onSelect(new Date(today.getTime() - 86400000 * 30))}>
              <Text style={cal.quickText}>一個月前</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={cal.closeBtn} onPress={onClose}>
            <Text style={cal.closeBtnText}>確定</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

function formatDate(date: Date | null): string {
  if (!date) return "點選選擇走失時間";
  return `${date.getFullYear()}/${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`;
}

// ─── 主畫面 ───────────────────────────────────────────────────────
export default function EditCaseScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [type, setType] = useState<CaseType>("lost");
  const [petName, setPetName] = useState("");
  const [petType, setPetType] = useState("");
  const [breed, setBreed] = useState("");
  const [color, setColor] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [contactName, setContactName] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [isUrgent, setIsUrgent] = useState(false);
  const [imageUri, setImageUri] = useState<string | undefined>();
  const [imageBase64, setImageBase64] = useState<string>("");
  const [incidentDate, setIncidentDate] = useState<Date | null>(null);
  const [showCalendar, setShowCalendar] = useState(false);

  // 載入現有案件資料
  useEffect(() => {
    if (!id) return;
    getCaseById(id).then((c: PetCase | null) => {
      if (!c) { Alert.alert("錯誤", "找不到案件"); router.back(); return; }
      setType(c.type);
      setPetName(c.petName);
      setPetType(c.petType);
      setBreed(c.breed);
      setColor(c.color);
      setLocation(c.location);
      setDescription(c.description);
      setContactName(c.contactName);
      setContactPhone(c.contactPhone);
      setIsUrgent(c.isUrgent);
      if (c.imageBase64) {
        setImageBase64(c.imageBase64);
        setImageUri(`data:image/jpeg;base64,${c.imageBase64}`);
      } else if (c.imageUri) {
        setImageUri(c.imageUri);
      }
      if (c.incidentDate) setIncidentDate(new Date(c.incidentDate));
      setLoading(false);
    });
  }, [id]);

  const pickImage = useCallback(async () => {
    try {
      if (Platform.OS !== "web") {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== "granted") {
          Alert.alert("需要權限", "請允許存取相片庫以選擇圖片");
          return;
        }
      }
      if (Platform.OS === "web") {
        const result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          allowsEditing: true,
          aspect: [4, 3],
          quality: 0.6,
          base64: true,
        });
        if (!result.canceled && result.assets[0]) {
          const asset = result.assets[0];
          if (asset.base64) {
            setImageBase64(asset.base64);
            setImageUri(`data:image/jpeg;base64,${asset.base64}`);
          }
        }
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
        base64: false,
      });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        const manipResult = await ImageManipulator.manipulateAsync(
          asset.uri,
          [{ resize: { width: 600 } }],
          { compress: 0.6, format: ImageManipulator.SaveFormat.JPEG, base64: true }
        );
        setImageUri(manipResult.uri);
        setImageBase64(manipResult.base64 ?? "");
      }
    } catch {
      Alert.alert("錯誤", "無法開啟相片庫");
    }
  }, []);

  const handleSave = async () => {
    if (!id) return;
    setSubmitting(true);
    try {
      await updateCase(id, {
        type,
        petName: petName.trim() || "未命名",
        petType: petType.trim(),
        breed: breed.trim(),
        color: color.trim(),
        location: location.trim(),
        description: description.trim(),
        contactName: contactName.trim(),
        contactPhone: contactPhone.trim(),
        imageBase64,
        imageUri,
        isUrgent,
        incidentDate: incidentDate ? incidentDate.toISOString() : undefined,
      });
      Alert.alert("儲存成功！", "案件已更新。", [
        { text: "確定", onPress: () => router.back() },
      ]);
    } catch (err) {
      console.error("更新失敗:", err);
      Alert.alert("更新失敗", "請確認網路連線後重試");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#F0F4FF" }}>
        <ActivityIndicator size="large" color="#1E40AF" />
      </View>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-[#1E40AF]" edges={["top", "left", "right"]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="arrow.left" size={20} color="#fff" />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>編輯案件</Text>
          <Text style={styles.headerSub}>修改後點擊儲存</Text>
        </View>
      </View>

      <ScrollView style={styles.body} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {/* 案件類型 */}
        <View style={styles.section}>
          <Text style={styles.label}>案件類型</Text>
          <View style={styles.typeRow}>
            {TYPES.map((t) => (
              <TouchableOpacity
                key={t.key}
                style={[styles.typeBtn, type === t.key && { backgroundColor: t.bg, borderColor: t.color }]}
                onPress={() => setType(t.key)}
                activeOpacity={0.75}
              >
                <Text style={styles.typeIcon}>{t.icon}</Text>
                <Text style={[styles.typeLabel, type === t.key && { color: t.color }]}>{t.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* 走失時間 */}
        <View style={styles.section}>
          <Text style={styles.label}>走失時間（選填）</Text>
          <TouchableOpacity
            style={styles.datePickerBtn}
            onPress={() => setShowCalendar(true)}
            activeOpacity={0.75}
          >
            <IconSymbol name="calendar" size={18} color="#2563EB" />
            <Text style={[styles.datePickerText, !incidentDate && styles.datePlaceholder]}>
              {formatDate(incidentDate)}
            </Text>
            {incidentDate && (
              <TouchableOpacity onPress={() => setIncidentDate(null)} style={styles.dateClearBtn}>
                <IconSymbol name="xmark" size={14} color="#9CA3AF" />
              </TouchableOpacity>
            )}
          </TouchableOpacity>
        </View>

        {/* 寵物資訊 */}
        <View style={styles.section}>
          <Text style={styles.label}>寵物資訊</Text>
          <View style={styles.card}>
            <View style={styles.row}>
              <View style={styles.half}>
                <Text style={styles.fieldLabel}>寵物名字</Text>
                <TextInput style={styles.input} placeholder="例：小白" value={petName} onChangeText={setPetName} returnKeyType="next" />
              </View>
              <View style={styles.half}>
                <Text style={styles.fieldLabel}>種類</Text>
                <TextInput style={styles.input} placeholder="例：狗、貓" value={petType} onChangeText={setPetType} returnKeyType="next" />
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.half}>
                <Text style={styles.fieldLabel}>品種</Text>
                <TextInput style={styles.input} placeholder="例：柴犬" value={breed} onChangeText={setBreed} returnKeyType="next" />
              </View>
              <View style={styles.half}>
                <Text style={styles.fieldLabel}>毛色</Text>
                <TextInput style={styles.input} placeholder="例：橘色" value={color} onChangeText={setColor} returnKeyType="next" />
              </View>
            </View>
          </View>
        </View>

        {/* 地點與描述 */}
        <View style={styles.section}>
          <Text style={styles.label}>地點與描述</Text>
          <View style={styles.card}>
            <Text style={styles.fieldLabel}>地點</Text>
            <TextInput style={styles.input} placeholder="例：台北市大安區" value={location} onChangeText={setLocation} returnKeyType="next" />
            <Text style={[styles.fieldLabel, { marginTop: 12 }]}>案件描述</Text>
            <TextInput
              style={[styles.input, styles.textarea]}
              placeholder="請描述寵物特徵、走失/拾獲時間、特殊標記等..."
              value={description}
              onChangeText={(t) => t.length <= 500 && setDescription(t)}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
            <Text style={styles.charCount}>{description.length}/500 字</Text>
          </View>
        </View>

        {/* 聯絡資訊 */}
        <View style={styles.section}>
          <Text style={styles.label}>聯絡資訊</Text>
          <View style={styles.card}>
            <Text style={styles.fieldLabel}>聯絡人姓名</Text>
            <TextInput style={styles.input} placeholder="您的姓名" value={contactName} onChangeText={setContactName} returnKeyType="next" />
            <Text style={[styles.fieldLabel, { marginTop: 12 }]}>聯絡電話</Text>
            <TextInput style={styles.input} placeholder="0912-345-678" value={contactPhone} onChangeText={setContactPhone} keyboardType="phone-pad" returnKeyType="done" />
          </View>
        </View>

        {/* 圖片 */}
        <View style={styles.section}>
          <Text style={styles.label}>寵物照片（選填）</Text>
          <View style={styles.card}>
            {imageUri ? (
              <View>
                <Image source={{ uri: imageUri }} style={styles.preview} resizeMode="cover" />
                <TouchableOpacity style={styles.removeImg} onPress={() => { setImageUri(undefined); setImageBase64(""); }}>
                  <IconSymbol name="xmark" size={14} color="#fff" />
                  <Text style={styles.removeImgText}>移除照片</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <TouchableOpacity style={styles.pickBtn} onPress={pickImage} activeOpacity={0.75}>
                <IconSymbol name="camera.fill" size={22} color="#2563EB" />
                <Text style={styles.pickBtnText}>選擇照片</Text>
                <Text style={styles.pickBtnSub}>支援 JPG、PNG（自動壓縮）</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* 緊急標記 */}
        <View style={styles.section}>
          <View style={styles.card}>
            <View style={styles.switchRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.switchLabel}>標記為緊急案件</Text>
                <Text style={styles.switchSub}>緊急案件將優先顯示在列表頂部</Text>
              </View>
              <Switch
                value={isUrgent}
                onValueChange={setIsUrgent}
                trackColor={{ false: "#D1D5DB", true: "#EF4444" }}
                thumbColor="#fff"
              />
            </View>
          </View>
        </View>

        {/* 儲存按鈕 */}
        <TouchableOpacity
          style={[styles.submitBtn, submitting && { opacity: 0.6 }]}
          onPress={handleSave}
          disabled={submitting}
          activeOpacity={0.85}
        >
          <Text style={styles.submitText}>{submitting ? "儲存中..." : "💾 儲存修改"}</Text>
        </TouchableOpacity>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* 行事曆 Modal */}
      <CalendarPicker
        visible={showCalendar}
        selectedDate={incidentDate}
        onSelect={(d) => { setIncidentDate(d); setShowCalendar(false); }}
        onClose={() => setShowCalendar(false)}
        title="選擇走失時間"
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { backgroundColor: "#1E40AF", paddingHorizontal: 16, paddingBottom: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  backBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 20, fontWeight: "700", color: "#fff" },
  headerSub: { fontSize: 12, color: "#BFDBFE", marginTop: 2 },
  body: { flex: 1, backgroundColor: "#F0F4FF" },
  section: { paddingHorizontal: 16, marginTop: 16 },
  label: { fontSize: 15, fontWeight: "700", color: "#111827", marginBottom: 10 },
  card: { backgroundColor: "#fff", borderRadius: 14, padding: 16 },
  typeRow: { flexDirection: "row", gap: 10 },
  typeBtn: { flex: 1, alignItems: "center", padding: 14, borderRadius: 12, backgroundColor: "#F3F4F6", borderWidth: 2, borderColor: "transparent", gap: 6 },
  typeIcon: { fontSize: 24 },
  typeLabel: { fontSize: 13, fontWeight: "700", color: "#6B7280" },
  row: { flexDirection: "row", gap: 12, marginBottom: 4 },
  half: { flex: 1 },
  fieldLabel: { fontSize: 12, color: "#6B7280", fontWeight: "600", marginBottom: 6 },
  input: { backgroundColor: "#F9FAFB", borderRadius: 10, paddingHorizontal: 12, paddingVertical: Platform.OS === "ios" ? 10 : 8, fontSize: 14, color: "#111827", borderWidth: 1, borderColor: "#E5E7EB", marginBottom: 4 },
  textarea: { minHeight: 90, paddingTop: 10 },
  charCount: { fontSize: 11, color: "#9CA3AF", textAlign: "right", marginTop: 2 },
  switchRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  switchLabel: { fontSize: 14, fontWeight: "700", color: "#111827" },
  switchSub: { fontSize: 12, color: "#6B7280", marginTop: 2 },
  pickBtn: { alignItems: "center", padding: 24, gap: 8 },
  pickBtnText: { fontSize: 15, fontWeight: "700", color: "#2563EB" },
  pickBtnSub: { fontSize: 12, color: "#9CA3AF" },
  preview: { width: "100%", height: 200, borderRadius: 10 },
  removeImg: { flexDirection: "row", alignItems: "center", justifyContent: "center", backgroundColor: "#EF4444", borderRadius: 8, padding: 8, marginTop: 8, gap: 4 },
  removeImgText: { color: "#fff", fontSize: 13, fontWeight: "600" },
  submitBtn: { marginHorizontal: 16, marginTop: 8, backgroundColor: "#2563EB", borderRadius: 14, paddingVertical: 16, alignItems: "center" },
  submitText: { fontSize: 16, fontWeight: "800", color: "#fff" },
  datePickerBtn: { flexDirection: "row", alignItems: "center", backgroundColor: "#fff", borderRadius: 12, padding: 14, gap: 10, borderWidth: 1.5, borderColor: "#DBEAFE" },
  datePickerText: { flex: 1, fontSize: 15, color: "#111827", fontWeight: "600" },
  datePlaceholder: { color: "#9CA3AF", fontWeight: "400" },
  dateClearBtn: { padding: 4 },
});

const cal = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center" },
  container: { backgroundColor: "#fff", borderRadius: 20, padding: 20, width: 320, shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 8 },
  title: { fontSize: 16, fontWeight: "700", color: "#111827", textAlign: "center", marginBottom: 16 },
  nav: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  navBtn: { padding: 8 },
  navArrow: { fontSize: 22, color: "#2563EB", fontWeight: "700" },
  navLabel: { fontSize: 15, fontWeight: "700", color: "#111827" },
  weekRow: { flexDirection: "row", marginBottom: 6 },
  weekDay: { flex: 1, textAlign: "center", fontSize: 12, color: "#9CA3AF", fontWeight: "600" },
  grid: { flexDirection: "row", flexWrap: "wrap" },
  cell: { width: "14.28%", aspectRatio: 1, justifyContent: "center", alignItems: "center" },
  cellSelected: { backgroundColor: "#2563EB", borderRadius: 100 },
  cellToday: { borderWidth: 1.5, borderColor: "#2563EB", borderRadius: 100 },
  cellText: { fontSize: 14, color: "#111827" },
  cellTextSelected: { color: "#fff", fontWeight: "700" },
  cellTextFuture: { color: "#D1D5DB" },
  cellTextToday: { color: "#2563EB", fontWeight: "700" },
  quickRow: { flexDirection: "row", gap: 8, marginTop: 12, justifyContent: "center" },
  quickBtn: { paddingHorizontal: 12, paddingVertical: 6, backgroundColor: "#EFF6FF", borderRadius: 20 },
  quickText: { fontSize: 12, color: "#2563EB", fontWeight: "600" },
  closeBtn: { marginTop: 16, backgroundColor: "#2563EB", borderRadius: 12, paddingVertical: 12, alignItems: "center" },
  closeBtnText: { color: "#fff", fontSize: 15, fontWeight: "700" },
});
