import { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Linking,
  Alert,
  ActivityIndicator,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import {
  getCaseById,
  toggleFavorite,
  getFavoriteIds,
  incrementViews,
  resolveCase,
  deleteCase,
  type PetCase,
  type CaseType,
} from "@/lib/firestore-cases";
import {
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";
import { db } from "@/lib/firebase";

const TYPE_LABEL: Record<CaseType, string> = { lost: "遺失", found: "拾獲", adoption: "認養", emergency: "緊急救護" };
const TYPE_COLOR: Record<CaseType, string> = { lost: "#EF4444", found: "#3B82F6", adoption: "#10B981", emergency: "#F97316" };
const TYPE_BG: Record<CaseType, string> = { lost: "#FEE2E2", found: "#DBEAFE", adoption: "#D1FAE5", emergency: "#FFEDD5" };

function timeAgo(iso: string | Timestamp): string {
  let ms: number;
  if (iso instanceof Timestamp) {
    ms = iso.toMillis();
  } else {
    ms = new Date(iso).getTime();
  }
  const diff = (Date.now() - ms) / 1000;
  if (diff < 60) return "剛剛";
  if (diff < 3600) return `${Math.floor(diff / 60)} 分鐘前`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小時前`;
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)} 天前`;
  const d = new Date(ms);
  return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}`;
}

interface Comment {
  id: string;
  text: string;
  nickname: string;
  createdAt: Timestamp | null;
}

export default function CaseDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const scrollRef = useRef<ScrollView>(null);

  const [petCase, setPetCase] = useState<PetCase | null>(null);
  const [isFav, setIsFav] = useState(false);
  const [loading, setLoading] = useState(true);
  const [resolving, setResolving] = useState(false);

  // 留言
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentText, setCommentText] = useState("");
  const [nickname, setNickname] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!id) return;
    const load = async () => {
      try {
        const [c, favIds] = await Promise.all([getCaseById(id), getFavoriteIds()]);
        setPetCase(c);
        setIsFav(favIds.includes(id));
        if (c) await incrementViews(id);
      } catch {
        // ignore
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  // 即時監聽 Firestore 留言
  useEffect(() => {
    if (!id) return;
    try {
      const q = query(
        collection(db, "cases", id, "comments"),
        orderBy("createdAt", "asc")
      );
      const unsub = onSnapshot(q, (snap) => {
        const list: Comment[] = snap.docs.map((doc) => ({
          id: doc.id,
          text: doc.data().text ?? "",
          nickname: doc.data().nickname ?? "匿名",
          createdAt: doc.data().createdAt ?? null,
        }));
        setComments(list);
      }, () => {
        // Firestore 連線失敗時靜默忽略
      });
      return () => unsub();
    } catch {
      // ignore
    }
  }, [id]);

  const handleEdit = () => {
    if (!id) return;
    router.push({ pathname: "/edit-case", params: { id } });
  };

  const handleDelete = () => {
    if (!id) return;
    Alert.alert(
      "刪除案件",
      "確定要刪除這個案件嗎？\n此操作無法復原，案件將從雲端永久移除。",
      [
        { text: "取消", style: "cancel" },
        {
          text: "確定刪除",
          style: "destructive",
          onPress: async () => {
            try {
              await deleteCase(id);
              Alert.alert("已刪除", "案件已成功刪除。", [
                { text: "確定", onPress: () => router.replace("/(tabs)/cases") },
              ]);
            } catch {
              Alert.alert("刪除失敗", "請確認網路連線後重試");
            }
          },
        },
      ]
    );
  };

  const handleResolve = async () => {
    if (!id || !petCase) return;
    const isResolved = petCase.resolved;
    const title = isResolved ? "取消已解決" : "標記為已解決";
    const msg = isResolved
      ? "確定要將案件恢復為「未解決」狀態？"
      : "確定要將案件標記為「已解決」？\n標記後將顯示「已解決」綠色標籤。";
    Alert.alert(title, msg, [
      { text: "取消", style: "cancel" },
      {
        text: "確定",
        style: isResolved ? "destructive" : "default",
        onPress: async () => {
          setResolving(true);
          try {
            await resolveCase(id, !isResolved);
            setPetCase((prev) => prev ? { ...prev, resolved: !isResolved, resolvedAt: !isResolved ? new Date().toISOString() : undefined } : prev);
          } catch {
            Alert.alert("錯誤", "更新失敗，請確認網路連線");
          } finally {
            setResolving(false);
          }
        },
      },
    ]);
  };

  const handleFav = async () => {
    if (!id) return;
    const newFav = await toggleFavorite(id);
    setIsFav(newFav);
  };

  const handleCall = () => {
    if (!petCase?.contactPhone) {
      Alert.alert("聯絡方式", "此案件未提供聯絡電話");
      return;
    }
    const phone = petCase.contactPhone.replace(/[^0-9+]/g, "");
    Linking.openURL(`tel:${phone}`).catch(() => Alert.alert("無法撥打電話"));
  };

  const handleSendComment = async () => {
    const text = commentText.trim();
    if (!text) return;
    if (!id) return;
    setSending(true);
    try {
      await addDoc(collection(db, "cases", id, "comments"), {
        text,
        nickname: nickname.trim() || "匿名",
        createdAt: serverTimestamp(),
      });
      setCommentText("");
      // 滾動到底部
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 300);
    } catch {
      Alert.alert("錯誤", "留言失敗，請確認網路連線");
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#1E40AF" />
      </View>
    );
  }

  if (!petCase) {
    return (
      <View style={styles.center}>
        <Text style={styles.notFoundText}>找不到此案件</Text>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>返回</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-[#1E40AF]" edges={["top", "left", "right"]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.iconBtn}>
          <IconSymbol name="arrow.left" size={22} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>案件詳情</Text>
        <TouchableOpacity onPress={handleFav} style={styles.iconBtn}>
          <IconSymbol name={isFav ? "heart.fill" : "heart"} size={22} color={isFav ? "#FCA5A5" : "#fff"} />
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={0}
      >
        <ScrollView
          ref={scrollRef}
          style={styles.body}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* 圖片 */}
          {(petCase.imageBase64 || petCase.imageUri) ? (
            <Image
              source={{ uri: petCase.imageBase64 ? `data:image/jpeg;base64,${petCase.imageBase64}` : petCase.imageUri }}
              style={styles.image}
              resizeMode="cover"
            />
          ) : (
            <View style={[styles.imagePlaceholder, { backgroundColor: TYPE_BG[petCase.type] }]}>
              <Text style={{ fontSize: 64 }}>
                {petCase.type === "lost" ? "🐾" : petCase.type === "found" ? "🤝" : petCase.type === "emergency" ? "🚨" : "💗"}
              </Text>
              <Text style={{ fontSize: 14, color: TYPE_COLOR[petCase.type], marginTop: 8, fontWeight: "600" }}>
                {TYPE_LABEL[petCase.type]} · 暫無照片
              </Text>
            </View>
          )}

          {/* 主要資訊 */}
          <View style={styles.mainCard}>
            <View style={styles.badgeRow}>
              <View style={[styles.badge, { backgroundColor: TYPE_BG[petCase.type] }]}>
                <Text style={[styles.badgeText, { color: TYPE_COLOR[petCase.type] }]}>{TYPE_LABEL[petCase.type]}</Text>
              </View>
              {petCase.isUrgent && (
                <View style={[styles.badge, { backgroundColor: "#FEE2E2" }]}>
                  <Text style={[styles.badgeText, { color: "#EF4444" }]}>🚨 緊急</Text>
                </View>
              )}
              {petCase.resolved && (
                <View style={styles.resolvedBadge}>
                  <Text style={styles.resolvedBadgeText}>✓ 已解決</Text>
                </View>
              )}
            </View>
            <Text style={styles.name}>{petCase.petName || "未命名"}</Text>
            <Text style={styles.breed}>
              {[petCase.petType, petCase.breed, petCase.color].filter(Boolean).join(" · ") || "未填寫寵物資訊"}
            </Text>
            <View style={styles.metaRow}>
              {petCase.location ? (
                <View style={styles.metaItem}>
                  <IconSymbol name="location.fill" size={13} color="#6B7280" />
                  <Text style={styles.metaText}>{petCase.location}</Text>
                </View>
              ) : null}
              {petCase.incidentDate ? (
                <View style={styles.metaItem}>
                  <IconSymbol name="clock.fill" size={13} color="#EF4444" />
                  <Text style={[styles.metaText, { color: "#EF4444", fontWeight: "600" }]}>走失 {timeAgo(petCase.incidentDate)}</Text>
                </View>
              ) : null}
              <View style={styles.metaItem}>
                <IconSymbol name="clock.fill" size={13} color="#6B7280" />
                <Text style={styles.metaText}>發文 {timeAgo(petCase.createdAt)}</Text>
              </View>
              <View style={styles.metaItem}>
                <IconSymbol name="eye.fill" size={13} color="#6B7280" />
                <Text style={styles.metaText}>{petCase.views}</Text>
              </View>
            </View>
          </View>

          {/* 描述 */}
          {petCase.description ? (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>案件描述</Text>
              <View style={styles.card}>
                <Text style={styles.desc}>{petCase.description}</Text>
              </View>
            </View>
          ) : null}

          {/* 聯絡 */}
          {(petCase.contactName || petCase.contactPhone) ? (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>聯絡資訊</Text>
              <View style={styles.card}>
                {petCase.contactName ? (
                  <View style={styles.contactRow}>
                    <IconSymbol name="person.fill" size={16} color="#6B7280" />
                    <Text style={styles.contactText}>{petCase.contactName}</Text>
                  </View>
                ) : null}
                {petCase.contactPhone ? (
                  <View style={styles.contactRow}>
                    <IconSymbol name="phone.fill" size={16} color="#6B7280" />
                    <Text style={styles.contactText}>{petCase.contactPhone}</Text>
                  </View>
                ) : null}
              </View>
            </View>
          ) : null}

          {/* 操作 */}
          <View style={styles.actions}>
            {petCase.contactPhone ? (
              <TouchableOpacity style={styles.callBtn} onPress={handleCall} activeOpacity={0.85}>
                <IconSymbol name="phone.fill" size={18} color="#fff" />
                <Text style={styles.callBtnText}>立即聯絡</Text>
              </TouchableOpacity>
            ) : null}
            <TouchableOpacity
              style={[styles.favBtn, isFav && styles.favBtnActive]}
              onPress={handleFav}
              activeOpacity={0.85}
            >
              <IconSymbol name={isFav ? "heart.fill" : "heart"} size={18} color={isFav ? "#EF4444" : "#6B7280"} />
              <Text style={[styles.favBtnText, isFav && { color: "#EF4444" }]}>{isFav ? "已收藏" : "收藏"}</Text>
            </TouchableOpacity>
          </View>

          {/* 編輯 / 刪除 按鈕列 */}
          <View style={styles.actionRow}>
            <TouchableOpacity style={styles.editBtn} onPress={handleEdit} activeOpacity={0.85}>
              <Text style={styles.editBtnText}>✏️ 編輯案件</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.deleteBtn} onPress={handleDelete} activeOpacity={0.85}>
              <Text style={styles.deleteBtnText}>🗑 刪除</Text>
            </TouchableOpacity>
          </View>

          {/* 已解決按鈕 */}
          <TouchableOpacity
            style={[styles.resolveBtn, petCase.resolved && styles.resolveBtnDone]}
            onPress={handleResolve}
            activeOpacity={0.85}
            disabled={resolving}
          >
            {resolving ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <>
                <Text style={styles.resolveIcon}>{petCase.resolved ? "🔄" : "✓"}</Text>
                <Text style={styles.resolveBtnText}>
                  {petCase.resolved ? "取消已解決" : "標記為已解決"}
                </Text>
              </>
            )}
          </TouchableOpacity>
          {petCase.resolved && petCase.resolvedAt ? (
            <Text style={styles.resolvedAtText}>✓ 案件於 {new Date(petCase.resolvedAt).toLocaleDateString("zh-TW")} 標記為已解決</Text>
          ) : null}

          {/* ===== 留言區 ===== */}
          <View style={styles.section}>
            <View style={styles.commentHeader}>
              <IconSymbol name="bubble.left.fill" size={16} color="#2563EB" />
              <Text style={styles.sectionTitle}>留言互動</Text>
              <View style={styles.commentCount}>
                <Text style={styles.commentCountText}>{comments.length}</Text>
              </View>
            </View>

            {/* 留言輸入 */}
            <View style={styles.commentInputCard}>
              <TextInput
                style={styles.nicknameInput}
                placeholder="您的暱稱（選填）"
                placeholderTextColor="#9CA3AF"
                value={nickname}
                onChangeText={setNickname}
                returnKeyType="next"
                maxLength={20}
              />
              <View style={styles.commentInputRow}>
                <TextInput
                  style={styles.commentInput}
                  placeholder="輸入留言，分享線索或加油打氣..."
                  placeholderTextColor="#9CA3AF"
                  value={commentText}
                  onChangeText={setCommentText}
                  multiline
                  maxLength={300}
                  returnKeyType="send"
                  onSubmitEditing={handleSendComment}
                />
                <TouchableOpacity
                  style={[styles.sendBtn, (!commentText.trim() || sending) && styles.sendBtnDisabled]}
                  onPress={handleSendComment}
                  disabled={!commentText.trim() || sending}
                  activeOpacity={0.8}
                >
                  {sending ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <IconSymbol name="paperplane.fill" size={16} color="#fff" />
                  )}
                </TouchableOpacity>
              </View>
              <Text style={styles.commentCharCount}>{commentText.length}/300</Text>
            </View>

            {/* 留言列表 */}
            {comments.length === 0 ? (
              <View style={styles.noComments}>
                <Text style={styles.noCommentsText}>還沒有留言，來第一個留言吧！</Text>
              </View>
            ) : (
              comments.map((c) => (
                <View key={c.id} style={styles.commentItem}>
                  <View style={styles.commentAvatar}>
                    <Text style={styles.commentAvatarText}>{c.nickname.charAt(0).toUpperCase()}</Text>
                  </View>
                  <View style={styles.commentBody}>
                    <View style={styles.commentMeta}>
                      <Text style={styles.commentNickname}>{c.nickname}</Text>
                      <Text style={styles.commentTime}>
                        {c.createdAt ? timeAgo(c.createdAt) : "剛剛"}
                      </Text>
                    </View>
                    <Text style={styles.commentText}>{c.text}</Text>
                  </View>
                </View>
              ))
            )}
          </View>

          <View style={{ height: 120 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#F0F4FF", gap: 16 },
  notFoundText: { fontSize: 18, color: "#6B7280" },
  backBtn: { backgroundColor: "#2563EB", borderRadius: 12, paddingHorizontal: 24, paddingVertical: 12 },
  backBtnText: { color: "#fff", fontWeight: "700" },
  header: { backgroundColor: "#1E40AF", flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 14 },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#fff" },
  iconBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  body: { flex: 1, backgroundColor: "#F0F4FF" },
  image: { width: "100%", height: 240 },
  imagePlaceholder: { width: "100%", height: 180, backgroundColor: "#E0E7FF", alignItems: "center", justifyContent: "center" },
  mainCard: { backgroundColor: "#fff", padding: 20, gap: 8 },
  badgeRow: { flexDirection: "row", gap: 8 },
  badge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  badgeText: { fontSize: 12, fontWeight: "700" },
  name: { fontSize: 24, fontWeight: "800", color: "#111827" },
  breed: { fontSize: 14, color: "#6B7280" },
  metaRow: { flexDirection: "row", flexWrap: "wrap", gap: 12, marginTop: 4 },
  metaItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  metaText: { fontSize: 12, color: "#6B7280" },
  section: { paddingHorizontal: 16, marginTop: 16 },
  sectionTitle: { fontSize: 15, fontWeight: "700", color: "#111827", marginBottom: 10 },
  card: { backgroundColor: "#fff", borderRadius: 14, padding: 16 },
  desc: { fontSize: 14, color: "#374151", lineHeight: 22 },
  contactRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 5 },
  contactText: { fontSize: 15, color: "#111827" },
  actions: { flexDirection: "row", paddingHorizontal: 16, marginTop: 20, gap: 12 },
  callBtn: { flex: 2, flexDirection: "row", alignItems: "center", justifyContent: "center", backgroundColor: "#2563EB", borderRadius: 14, paddingVertical: 14, gap: 8 },
  callBtnText: { fontSize: 15, fontWeight: "700", color: "#fff" },
  favBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", backgroundColor: "#fff", borderRadius: 14, paddingVertical: 14, gap: 6, borderWidth: 1.5, borderColor: "#E5E7EB" },
  favBtnActive: { borderColor: "#FCA5A5", backgroundColor: "#FFF1F2" },
  favBtnText: { fontSize: 14, fontWeight: "700", color: "#6B7280" },
  // 留言區
  commentHeader: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 10 },
  commentCount: { backgroundColor: "#2563EB", borderRadius: 10, paddingHorizontal: 7, paddingVertical: 2 },
  commentCountText: { fontSize: 11, color: "#fff", fontWeight: "700" },
  commentInputCard: { backgroundColor: "#fff", borderRadius: 14, padding: 14, marginBottom: 12 },
  nicknameInput: { backgroundColor: "#F3F4F6", borderRadius: 8, paddingHorizontal: 12, paddingVertical: Platform.OS === "ios" ? 8 : 6, fontSize: 13, color: "#111827", marginBottom: 10, borderWidth: 1, borderColor: "#E5E7EB" },
  commentInputRow: { flexDirection: "row", gap: 8, alignItems: "flex-end" },
  commentInput: { flex: 1, backgroundColor: "#F3F4F6", borderRadius: 10, paddingHorizontal: 12, paddingVertical: Platform.OS === "ios" ? 8 : 6, fontSize: 14, color: "#111827", minHeight: 44, maxHeight: 100, borderWidth: 1, borderColor: "#E5E7EB" },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: "#2563EB", alignItems: "center", justifyContent: "center" },
  sendBtnDisabled: { backgroundColor: "#93C5FD" },
  commentCharCount: { fontSize: 11, color: "#9CA3AF", textAlign: "right", marginTop: 4 },
  noComments: { backgroundColor: "#fff", borderRadius: 14, padding: 24, alignItems: "center" },
  noCommentsText: { fontSize: 13, color: "#9CA3AF" },
  commentItem: { flexDirection: "row", gap: 10, backgroundColor: "#fff", borderRadius: 12, padding: 12, marginBottom: 8 },
  commentAvatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: "#2563EB", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  commentAvatarText: { fontSize: 16, fontWeight: "700", color: "#fff" },
  commentBody: { flex: 1 },
  commentMeta: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 4 },
  commentNickname: { fontSize: 13, fontWeight: "700", color: "#111827" },
  commentTime: { fontSize: 11, color: "#9CA3AF" },
  commentText: { fontSize: 14, color: "#374151", lineHeight: 20 },
  // 已解決標籤
  resolvedBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4, backgroundColor: "#D1FAE5" },
  resolvedBadgeText: { fontSize: 12, fontWeight: "700", color: "#059669" },
  // 已解決按鈕
  resolveBtn: { marginHorizontal: 16, marginTop: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", backgroundColor: "#059669", borderRadius: 14, paddingVertical: 14, gap: 8 },
  resolveBtnDone: { backgroundColor: "#9CA3AF" },
  resolveIcon: { fontSize: 16, color: "#fff" },
  resolveBtnText: { fontSize: 15, fontWeight: "700", color: "#fff" },
  resolvedAtText: { textAlign: "center", fontSize: 12, color: "#059669", marginTop: 8, marginBottom: 4 },
  // 編輯/刪除按鈕列
  actionRow: { flexDirection: "row", gap: 10, marginHorizontal: 16, marginTop: 12 },
  editBtn: { flex: 1, backgroundColor: "#EFF6FF", borderRadius: 12, paddingVertical: 12, alignItems: "center", borderWidth: 1.5, borderColor: "#BFDBFE" },
  editBtnText: { fontSize: 14, fontWeight: "700", color: "#1E40AF" },
  deleteBtn: { backgroundColor: "#FEF2F2", borderRadius: 12, paddingVertical: 12, paddingHorizontal: 20, alignItems: "center", borderWidth: 1.5, borderColor: "#FECACA" },
  deleteBtnText: { fontSize: 14, fontWeight: "700", color: "#EF4444" },
});
