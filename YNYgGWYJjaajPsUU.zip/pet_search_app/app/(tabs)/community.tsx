import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  StyleSheet,
} from "react-native";
import {
  collection,
  query,
  orderBy,
  limit,
  getDocs,
  startAfter,
  type QueryDocumentSnapshot,
  type DocumentData,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useRouter } from "expo-router";

interface Post {
  id: string;
  text: string;
  imageBase64: string;
  caseType: "lost" | "found" | "adopt";
  petType: string;
  authorName: string;
  location: {
    latitude: number;
    longitude: number;
    address: string;
  } | null;
  createdAt: { seconds: number; nanoseconds: number } | null;
}

const CASE_TYPE_CONFIG = {
  lost: { label: "遺失", color: "#EF4444", bg: "#FEF2F2" },
  found: { label: "拾獲", color: "#3B82F6", bg: "#EFF6FF" },
  adopt: { label: "認養", color: "#22C55E", bg: "#F0FDF4" },
};

const PAGE_SIZE = 10;

function formatTime(seconds: number): string {
  const now = Date.now() / 1000;
  const diff = now - seconds;
  if (diff < 60) return "剛剛";
  if (diff < 3600) return `${Math.floor(diff / 60)} 分鐘前`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小時前`;
  return `${Math.floor(diff / 86400)} 天前`;
}

function PostCard({ post }: { post: Post }) {
  const colors = useColors();
  const caseConfig = CASE_TYPE_CONFIG[post.caseType] ?? CASE_TYPE_CONFIG.lost;

  return (
    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      {/* 頂部：類型標籤 + 時間 */}
      <View style={styles.cardHeader}>
        <View style={[styles.badge, { backgroundColor: caseConfig.bg }]}>
          <Text style={[styles.badgeText, { color: caseConfig.color }]}>{caseConfig.label}</Text>
        </View>
        {post.petType ? (
          <Text style={[styles.petType, { color: colors.muted }]}>{post.petType}</Text>
        ) : null}
        <Text style={[styles.timeText, { color: colors.muted }]}>
          {post.createdAt ? formatTime(post.createdAt.seconds) : ""}
        </Text>
      </View>

      {/* 圖片 */}
      {post.imageBase64 ? (
        <Image source={{ uri: `data:image/jpeg;base64,${post.imageBase64}` }} style={styles.postImage} resizeMode="cover" />
      ) : null}

      {/* 貼文內容 */}
      <Text style={[styles.postText, { color: colors.foreground }]} numberOfLines={4}>
        {post.text}
      </Text>

      {/* 底部：位置 + 作者 */}
      <View style={styles.cardFooter}>
        {post.location ? (
          <View style={styles.locationRow}>
            <IconSymbol name="location.fill" size={12} color={colors.muted} />
            <Text style={[styles.locationText, { color: colors.muted }]} numberOfLines={1}>
              {post.location.address}
            </Text>
          </View>
        ) : null}
        <View style={styles.authorRow}>
          <IconSymbol name="person.fill" size={12} color={colors.muted} />
          <Text style={[styles.authorText, { color: colors.muted }]}>{post.authorName}</Text>
        </View>
      </View>
    </View>
  );
}

export default function CommunityScreen() {
  const colors = useColors();
  const router = useRouter();
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [lastDoc, setLastDoc] = useState<QueryDocumentSnapshot<DocumentData> | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<"all" | "lost" | "found" | "adopt">("all");

  const fetchPosts = useCallback(async (refresh = false) => {
    try {
      setError(null);
      const postsRef = collection(db, "posts");
      const q = query(postsRef, orderBy("createdAt", "desc"), limit(PAGE_SIZE));
      const snapshot = await getDocs(q);

      const fetched: Post[] = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...(doc.data() as Omit<Post, "id">),
      }));

      setPosts(fetched);
      setLastDoc(snapshot.docs[snapshot.docs.length - 1] ?? null);
      setHasMore(snapshot.docs.length === PAGE_SIZE);
    } catch (err) {
      console.error("載入貼文失敗:", err);
      setError("載入失敗，請確認網路連線後重試");
    }
  }, []);

  const loadMore = useCallback(async () => {
    if (!hasMore || isLoadingMore || !lastDoc) return;
    try {
      setIsLoadingMore(true);
      const postsRef = collection(db, "posts");
      const q = query(
        postsRef,
        orderBy("createdAt", "desc"),
        startAfter(lastDoc),
        limit(PAGE_SIZE)
      );
      const snapshot = await getDocs(q);
      const fetched: Post[] = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...(doc.data() as Omit<Post, "id">),
      }));
      setPosts((prev) => [...prev, ...fetched]);
      setLastDoc(snapshot.docs[snapshot.docs.length - 1] ?? null);
      setHasMore(snapshot.docs.length === PAGE_SIZE);
    } catch (err) {
      console.error("載入更多失敗:", err);
    } finally {
      setIsLoadingMore(false);
    }
  }, [hasMore, isLoadingMore, lastDoc]);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await fetchPosts(true);
    setIsRefreshing(false);
  }, [fetchPosts]);

  useEffect(() => {
    setIsLoading(true);
    fetchPosts().finally(() => setIsLoading(false));
  }, [fetchPosts]);

  const displayPosts =
    filterType === "all" ? posts : posts.filter((p) => p.caseType === filterType);

  const renderHeader = () => (
    <View>
      {/* 頂部標題 */}
      <View style={[styles.header, { backgroundColor: "#1A56DB" }]}>
        <Text style={styles.headerTitle}>社群協尋</Text>
        <Text style={styles.headerSubtitle}>所有用戶發布的協尋資訊</Text>
      </View>

      {/* 篩選 Tab */}
      <View style={[styles.filterRow, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        {(["all", "lost", "found", "adopt"] as const).map((type) => {
          const label =
            type === "all"
              ? "全部"
              : CASE_TYPE_CONFIG[type]?.label ?? type;
          const isActive = filterType === type;
          return (
            <TouchableOpacity
              key={type}
              style={[styles.filterTab, isActive && styles.filterTabActive]}
              onPress={() => setFilterType(type)}
            >
              <Text
                style={[
                  styles.filterTabText,
                  { color: isActive ? "#1A56DB" : colors.muted },
                ]}
              >
                {label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  if (isLoading) {
    return (
      <ScreenContainer>
        {renderHeader()}
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#1A56DB" />
          <Text style={[styles.loadingText, { color: colors.muted }]}>載入中...</Text>
        </View>
      </ScreenContainer>
    );
  }

  if (error) {
    return (
      <ScreenContainer>
        {renderHeader()}
        <View style={styles.centered}>
          <IconSymbol name="exclamationmark.triangle.fill" size={48} color="#F59E0B" />
          <Text style={[styles.errorText, { color: colors.foreground }]}>{error}</Text>
          <TouchableOpacity
            style={styles.retryBtn}
            onPress={() => {
              setIsLoading(true);
              fetchPosts().finally(() => setIsLoading(false));
            }}
          >
            <Text style={styles.retryBtnText}>重試</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background">
      <FlatList
        data={displayPosts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <PostCard post={item} />}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={
          <View style={styles.centered}>
            <IconSymbol name="doc.text" size={48} color={colors.muted} />
            <Text style={[styles.emptyText, { color: colors.muted }]}>
              目前沒有貼文，成為第一個發布的人！
            </Text>
          </View>
        }
        ListFooterComponent={
          isLoadingMore ? (
            <View style={styles.footerLoader}>
              <ActivityIndicator size="small" color="#1A56DB" />
            </View>
          ) : null
        }
        onEndReached={loadMore}
        onEndReachedThreshold={0.3}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor="#1A56DB"
          />
        }
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />

      {/* 發布按鈕（浮動） */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => router.push("/(tabs)/community-post")}
      >
        <IconSymbol name="plus" size={28} color="#fff" />
      </TouchableOpacity>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.8)",
  },
  filterRow: {
    flexDirection: "row",
    borderBottomWidth: 1,
    paddingHorizontal: 8,
  },
  filterTab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: "center",
  },
  filterTabActive: {
    borderBottomWidth: 2,
    borderBottomColor: "#1A56DB",
  },
  filterTabText: {
    fontSize: 14,
    fontWeight: "600",
  },
  listContent: {
    paddingBottom: 100,
  },
  card: {
    marginHorizontal: 12,
    marginTop: 12,
    borderRadius: 14,
    borderWidth: 1,
    overflow: "hidden",
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingTop: 12,
    paddingBottom: 8,
    gap: 8,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: "700",
  },
  petType: {
    fontSize: 13,
    flex: 1,
  },
  timeText: {
    fontSize: 12,
  },
  postImage: {
    width: "100%",
    height: 200,
  },
  postText: {
    fontSize: 15,
    lineHeight: 22,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  cardFooter: {
    paddingHorizontal: 14,
    paddingBottom: 12,
    gap: 4,
  },
  locationRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  locationText: {
    fontSize: 12,
    flex: 1,
  },
  authorRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  authorText: {
    fontSize: 12,
  },
  centered: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
    gap: 12,
  },
  loadingText: {
    fontSize: 14,
  },
  errorText: {
    fontSize: 15,
    textAlign: "center",
    paddingHorizontal: 32,
  },
  emptyText: {
    fontSize: 15,
    textAlign: "center",
    paddingHorizontal: 32,
  },
  retryBtn: {
    backgroundColor: "#1A56DB",
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 8,
    marginTop: 8,
  },
  retryBtnText: {
    color: "#fff",
    fontWeight: "600",
  },
  footerLoader: {
    paddingVertical: 20,
    alignItems: "center",
  },
  fab: {
    position: "absolute",
    bottom: 24,
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "#1A56DB",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 8,
  },
});
