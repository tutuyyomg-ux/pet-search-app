import { useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  RefreshControl,
  Platform,
  Modal,
  Image,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { getCases, type PetCase, type CaseType } from "@/lib/firestore-cases";
import { useFocusEffect } from "@react-navigation/native";

const TYPE_LABEL: Record<CaseType, string> = { lost: "遺失", found: "拾獲", adoption: "認養", emergency: "緊急救護" };
const TYPE_COLOR: Record<CaseType, string> = { lost: "#EF4444", found: "#3B82F6", adoption: "#10B981", emergency: "#F97316" };
const TYPE_BG: Record<CaseType, string> = { lost: "#FEE2E2", found: "#DBEAFE", adoption: "#D1FAE5", emergency: "#FFEDD5" };

function timeAgo(iso: string): string {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return "剛剛";
  if (diff < 3600) return `${Math.floor(diff / 60)} 分鐘前`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小時前`;
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)} 天前`;
  const d = new Date(iso);
  return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}`;
}

function formatDate(date: Date | null): string {
  if (!date) return "";
  return `${date.getFullYear()}/${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}`;
}

const TYPE_FILTERS = [
  { key: "all", label: "全部" },
  { key: "lost", label: "遺失" },
  { key: "found", label: "拾獲" },
  { key: "adoption", label: "認養" },
  { key: "emergency", label: "緊急救護" },
];

// ─── 行事曆元件 ───────────────────────────────────────────────────
function CalendarPicker({
  visible,
  selectedDate,
  onSelect,
  onClose,
  title,
}: {
  visible: boolean;
  selectedDate: Date | null;
  onSelect: (date: Date) => void;
  onClose: () => void;
  title: string;
}) {
  const today = new Date();
  const [viewYear, setViewYear] = useState(selectedDate?.getFullYear() ?? today.getFullYear());
  const [viewMonth, setViewMonth] = useState(selectedDate?.getMonth() ?? today.getMonth());

  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const firstDayOfWeek = new Date(viewYear, viewMonth, 1).getDay();
  const WEEKDAYS = ["日", "一", "二", "三", "四", "五", "六"];

  const prevMonth = () => {
    if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1); }
    else setViewMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1); }
    else setViewMonth(m => m + 1);
  };

  const isSelected = (day: number) =>
    selectedDate &&
    selectedDate.getFullYear() === viewYear &&
    selectedDate.getMonth() === viewMonth &&
    selectedDate.getDate() === day;

  const isToday = (day: number) =>
    today.getFullYear() === viewYear &&
    today.getMonth() === viewMonth &&
    today.getDate() === day;

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDayOfWeek; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableOpacity style={cal.overlay} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} style={cal.container}>
          <Text style={cal.title}>{title}</Text>
          <View style={cal.nav}>
            <TouchableOpacity onPress={prevMonth} style={cal.navBtn}>
              <Text style={cal.navArrow}>‹</Text>
            </TouchableOpacity>
            <Text style={cal.navLabel}>{viewYear} 年 {viewMonth + 1} 月</Text>
            <TouchableOpacity onPress={nextMonth} style={cal.navBtn}>
              <Text style={cal.navArrow}>›</Text>
            </TouchableOpacity>
          </View>
          <View style={cal.weekRow}>
            {WEEKDAYS.map((w) => (
              <Text key={w} style={cal.weekDay}>{w}</Text>
            ))}
          </View>
          <View style={cal.grid}>
            {cells.map((day, idx) => {
              if (!day) return <View key={`empty-${idx}`} style={cal.cell} />;
              const sel = isSelected(day);
              const tod = isToday(day);
              return (
                <TouchableOpacity
                  key={day}
                  style={[cal.cell, sel && cal.cellSelected, tod && !sel && cal.cellToday]}
                  onPress={() => onSelect(new Date(viewYear, viewMonth, day))}
                  activeOpacity={0.7}
                >
                  <Text style={[cal.cellText, sel && cal.cellTextSelected, tod && !sel && cal.cellTextToday]}>
                    {day}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
          <View style={cal.quickRow}>
            {[
              { label: "今天", days: 0 },
              { label: "本週", days: 7 },
              { label: "本月", days: 30 },
              { label: "三個月", days: 90 },
            ].map(({ label, days }) => (
              <TouchableOpacity
                key={label}
                style={cal.quickBtn}
                onPress={() => {
                  const d = new Date();
                  d.setDate(d.getDate() - days);
                  onSelect(d);
                }}
              >
                <Text style={cal.quickText}>{label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity style={cal.closeBtn} onPress={onClose}>
            <Text style={cal.closeBtnText}>確定</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

// ─── 主畫面 ───────────────────────────────────────────────────────
export default function CasesScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ type?: string }>();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<string>(params.type ?? "all");
  const [dateFrom, setDateFrom] = useState<Date | null>(null);
  const [dateTo, setDateTo] = useState<Date | null>(null);
  const [showFromCal, setShowFromCal] = useState(false);
  const [showToCal, setShowToCal] = useState(false);
  const [cases, setCases] = useState<PetCase[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const data = await getCases();
      setCases(data);
    } catch (err) {
      console.error("載入案件失敗:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const filtered = cases.filter((c) => {
    const matchType = filter === "all" || c.type === filter;
    // 優先用走失時間（incidentDate），無則用發文時間（createdAt）
    const caseDate = new Date(c.incidentDate ?? c.createdAt);
    const matchFrom = !dateFrom || caseDate >= dateFrom;
    const matchTo = !dateTo || caseDate <= new Date(dateTo.getFullYear(), dateTo.getMonth(), dateTo.getDate(), 23, 59, 59);
    const q = search.trim().toLowerCase();
    const matchSearch =
      !q ||
      c.petName.toLowerCase().includes(q) ||
      c.petType.toLowerCase().includes(q) ||
      c.breed.toLowerCase().includes(q) ||
      c.location.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q);
    return matchType && matchFrom && matchTo && matchSearch;
  });

  const clearDateFilter = () => { setDateFrom(null); setDateTo(null); };
  const hasDateFilter = dateFrom !== null || dateTo !== null;

  const getImageSource = (item: PetCase) => {
    if (item.imageBase64) return { uri: `data:image/jpeg;base64,${item.imageBase64}` };
    if (item.imageUri) return { uri: item.imageUri };
    return null;
  };

  const renderItem = ({ item }: { item: PetCase }) => {
    const imgSrc = getImageSource(item);
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => router.push({ pathname: "/case-detail", params: { id: item.id } })}
        activeOpacity={0.8}
      >
        {/* 縮圖 */}
        <View style={styles.thumb}>
          {imgSrc ? (
            <Image source={imgSrc} style={styles.thumbImg} resizeMode="cover" />
          ) : (
            <View style={[styles.thumbPlaceholder, { backgroundColor: TYPE_BG[item.type] }]}>
              <Text style={styles.thumbEmoji}>
                {item.type === "lost" ? "🐾" : item.type === "found" ? "🤝" : item.type === "emergency" ? "🚨" : "💗"}
              </Text>
              <Text style={[styles.thumbType, { color: TYPE_COLOR[item.type] }]}>
                {TYPE_LABEL[item.type]}
              </Text>
            </View>
          )}
        </View>

        {/* 內容 */}
        <View style={styles.cardBody}>
          <View style={styles.cardTop}>
            <View style={styles.badges}>
              <View style={[styles.badge, { backgroundColor: TYPE_BG[item.type] }]}>
                <Text style={[styles.badgeText, { color: TYPE_COLOR[item.type] }]}>{TYPE_LABEL[item.type]}</Text>
              </View>
              {item.isUrgent && (
                <View style={[styles.badge, { backgroundColor: "#FEE2E2" }]}>
                  <Text style={[styles.badgeText, { color: "#EF4444" }]}>緊急</Text>
                </View>
              )}
              {item.resolved && (
                <View style={styles.resolvedBadge}>
                  <Text style={styles.resolvedBadgeText}>✓ 已解決</Text>
                </View>
              )}
            </View>
            <Text style={styles.time}>{timeAgo(item.createdAt)}</Text>
          </View>
          <Text style={styles.name} numberOfLines={1}>{item.petName || "未命名"}</Text>
          <Text style={styles.breed} numberOfLines={1}>
            {[item.petType, item.breed, item.color].filter(Boolean).join(" · ") || "未填寫品種"}
          </Text>
          {item.description ? (
            <Text style={styles.desc} numberOfLines={2}>{item.description}</Text>
          ) : null}
          <View style={styles.footer}>
            <View style={styles.metaItem}>
              <IconSymbol name="location.fill" size={12} color="#6B7280" />
              <Text style={styles.metaText} numberOfLines={1}>{item.location || "未填寫地點"}</Text>
            </View>
            <View style={styles.metaItem}>
              <IconSymbol name="eye.fill" size={12} color="#6B7280" />
              <Text style={styles.metaText}>{item.views}</Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenContainer containerClassName="bg-[#1E40AF]" edges={["top", "left", "right"]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>案件列表</Text>
        <Text style={styles.headerSub}>{loading ? "載入中..." : `${filtered.length} 個案件`}</Text>
      </View>

      {/* 搜尋 */}
      <View style={styles.searchWrap}>
        <View style={styles.searchBox}>
          <IconSymbol name="magnifyingglass" size={17} color="#6B7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="搜尋品種、地點、描述..."
            placeholderTextColor="#9CA3AF"
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch("")}>
              <IconSymbol name="xmark" size={15} color="#9CA3AF" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* 類型篩選 */}
      <View style={styles.filterWrap}>
        {TYPE_FILTERS.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.filterBtn, filter === f.key && styles.filterBtnActive]}
            onPress={() => setFilter(f.key)}
            activeOpacity={0.75}
          >
            <Text style={[styles.filterText, filter === f.key && styles.filterTextActive]}>{f.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* 日期範圍篩選 */}
      <View style={styles.dateFilterWrap}>
        <View style={styles.dateFilterRow}>
          <TouchableOpacity
            style={[styles.datePicker, dateFrom && styles.datePickerActive]}
            onPress={() => setShowFromCal(true)}
            activeOpacity={0.75}
          >
            <IconSymbol name="calendar" size={13} color={dateFrom ? "#2563EB" : "#9CA3AF"} />
            <Text style={[styles.datePickerText, !dateFrom && styles.datePickerPlaceholder]}>
              {dateFrom ? formatDate(dateFrom) : "開始日期"}
            </Text>
          </TouchableOpacity>

          <Text style={styles.dateSep}>—</Text>

          <TouchableOpacity
            style={[styles.datePicker, dateTo && styles.datePickerActive]}
            onPress={() => setShowToCal(true)}
            activeOpacity={0.75}
          >
            <IconSymbol name="calendar" size={13} color={dateTo ? "#2563EB" : "#9CA3AF"} />
            <Text style={[styles.datePickerText, !dateTo && styles.datePickerPlaceholder]}>
              {dateTo ? formatDate(dateTo) : "結束日期"}
            </Text>
          </TouchableOpacity>

          {hasDateFilter && (
            <TouchableOpacity style={styles.clearDateBtn} onPress={clearDateFilter}>
              <IconSymbol name="xmark" size={13} color="#EF4444" />
              <Text style={styles.clearDateText}>清除</Text>
            </TouchableOpacity>
          )}
        </View>
        {hasDateFilter && (
          <Text style={styles.dateFilterHint}>
            以走失時間筛選：{dateFrom ? formatDate(dateFrom) : "最早"} ～ {dateTo ? formatDate(dateTo) : "今天（無走失時間者改用發文時間）"}
          </Text>
        )}
      </View>

      {/* 列表 */}
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#2563EB" />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>🐾</Text>
            <Text style={styles.emptyText}>
              {loading ? "載入中..." : search ? "找不到符合的案件" : hasDateFilter ? "此日期範圍內沒有案件" : "目前沒有案件"}
            </Text>
            {!loading && !search && !hasDateFilter && (
              <Text style={styles.emptyHint}>點擊下方 + 按鈕發布第一個案件</Text>
            )}
          </View>
        }
      />

      {/* 行事曆 Modal */}
      <CalendarPicker
        visible={showFromCal}
        selectedDate={dateFrom}
        onSelect={(d) => { setDateFrom(d); setShowFromCal(false); }}
        onClose={() => setShowFromCal(false)}
        title="選擇走失時間（開始）"
      />
      <CalendarPicker
        visible={showToCal}
        selectedDate={dateTo}
        onSelect={(d) => { setDateTo(d); setShowToCal(false); }}
        onClose={() => setShowToCal(false)}
        title="選擇走失時間（結束）"
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { backgroundColor: "#1E40AF", paddingHorizontal: 16, paddingBottom: 10, flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end" },
  headerTitle: { fontSize: 22, fontWeight: "700", color: "#fff" },
  headerSub: { fontSize: 13, color: "#BFDBFE" },
  searchWrap: { backgroundColor: "#1E40AF", paddingHorizontal: 16, paddingBottom: 12 },
  searchBox: { flexDirection: "row", alignItems: "center", backgroundColor: "#fff", borderRadius: 22, paddingHorizontal: 14, paddingVertical: Platform.OS === "ios" ? 9 : 5, gap: 8 },
  searchInput: { flex: 1, fontSize: 14, color: "#111827" },
  filterWrap: { flexDirection: "row", backgroundColor: "#fff", paddingHorizontal: 16, paddingVertical: 10, gap: 8, borderBottomWidth: 0.5, borderBottomColor: "#E5E7EB" },
  filterBtn: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, backgroundColor: "#F3F4F6" },
  filterBtnActive: { backgroundColor: "#2563EB" },
  filterText: { fontSize: 13, color: "#6B7280", fontWeight: "600" },
  filterTextActive: { color: "#fff" },
  dateFilterWrap: { backgroundColor: "#fff", paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 0.5, borderBottomColor: "#E5E7EB" },
  dateFilterRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  datePicker: { flex: 1, flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#F3F4F6", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7, borderWidth: 1, borderColor: "transparent" },
  datePickerActive: { backgroundColor: "#EFF6FF", borderColor: "#2563EB" },
  datePickerText: { fontSize: 12, color: "#111827", fontWeight: "600", flex: 1 },
  datePickerPlaceholder: { color: "#9CA3AF", fontWeight: "400" },
  dateSep: { fontSize: 14, color: "#9CA3AF", fontWeight: "600" },
  clearDateBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 6 },
  clearDateText: { fontSize: 12, color: "#EF4444", fontWeight: "600" },
  dateFilterHint: { fontSize: 11, color: "#6B7280", marginTop: 6 },
  list: { padding: 16, paddingBottom: 100 },
  card: { backgroundColor: "#fff", borderRadius: 14, marginBottom: 12, flexDirection: "row", overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
  thumb: { width: 110, height: 120 },
  thumbImg: { width: 110, height: 120 },
  thumbPlaceholder: { width: 110, height: 120, justifyContent: "center", alignItems: "center", gap: 4 },
  thumbEmoji: { fontSize: 28 },
  thumbType: { fontSize: 11, fontWeight: "700" },
  cardBody: { flex: 1, padding: 12 },
  cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 6 },
  badges: { flexDirection: "row", gap: 4 },
  badge: { borderRadius: 6, paddingHorizontal: 7, paddingVertical: 2 },
  badgeText: { fontSize: 10, fontWeight: "700" },
  time: { fontSize: 10, color: "#9CA3AF" },
  name: { fontSize: 16, fontWeight: "700", color: "#111827", marginBottom: 2 },
  breed: { fontSize: 12, color: "#6B7280", marginBottom: 4 },
  desc: { fontSize: 12, color: "#374151", lineHeight: 17, marginBottom: 6 },
  footer: { flexDirection: "row", gap: 12 },
  metaItem: { flexDirection: "row", alignItems: "center", gap: 3 },
  metaText: { fontSize: 11, color: "#6B7280" },
  empty: { alignItems: "center", paddingVertical: 60 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyText: { fontSize: 15, color: "#9CA3AF" },
  emptyHint: { fontSize: 13, color: "#BFDBFE", marginTop: 6 },
  resolvedBadge: { borderRadius: 6, paddingHorizontal: 7, paddingVertical: 2, backgroundColor: "#D1FAE5" },
  resolvedBadgeText: { fontSize: 10, fontWeight: "700", color: "#059669" },
});

// ─── 行事曆樣式 ───────────────────────────────────────────────────
const cal = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center" },
  container: { backgroundColor: "#fff", borderRadius: 20, padding: 20, width: 320, shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 8 },
  title: { fontSize: 16, fontWeight: "700", color: "#111827", textAlign: "center", marginBottom: 16 },
  nav: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  navBtn: { padding: 8 },
  navArrow: { fontSize: 22, color: "#2563EB", fontWeight: "700" },
  navLabel: { fontSize: 15, fontWeight: "700", color: "#111827" },
  weekRow: { flexDirection: "row", marginBottom: 6 },
  weekDay: { flex: 1, textAlign: "center", fontSize: 12, color: "#9CA3AF", fontWeight: "600" },
  grid: { flexDirection: "row", flexWrap: "wrap" },
  cell: { width: "14.28%", aspectRatio: 1, justifyContent: "center", alignItems: "center" },
  cellSelected: { backgroundColor: "#2563EB", borderRadius: 100 },
  cellToday: { borderWidth: 1.5, borderColor: "#2563EB", borderRadius: 100 },
  cellText: { fontSize: 14, color: "#111827" },
  cellTextSelected: { color: "#fff", fontWeight: "700" },
  cellTextToday: { color: "#2563EB", fontWeight: "700" },
  quickRow: { flexDirection: "row", gap: 6, marginTop: 12, justifyContent: "center", flexWrap: "wrap" },
  quickBtn: { paddingHorizontal: 10, paddingVertical: 5, backgroundColor: "#EFF6FF", borderRadius: 20 },
  quickText: { fontSize: 11, color: "#2563EB", fontWeight: "600" },
  closeBtn: { marginTop: 16, backgroundColor: "#2563EB", borderRadius: 12, paddingVertical: 12, alignItems: "center" },
  closeBtnText: { color: "#fff", fontSize: 15, fontWeight: "700" },
});
