import { useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  Image,
} from "react-native";
import { useRouter } from "expo-router";
import { useFocusEffect } from "@react-navigation/native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { getCases, getFavoriteIds, type PetCase, type CaseType } from "@/lib/firestore-cases";

const TYPE_LABEL: Record<CaseType, string> = { lost: "遺失", found: "拾獲", adoption: "認養", emergency: "緊急救護" };
const TYPE_COLOR: Record<CaseType, string> = { lost: "#EF4444", found: "#3B82F6", adoption: "#10B981", emergency: "#F97316" };
const TYPE_BG: Record<CaseType, string> = { lost: "#FEE2E2", found: "#DBEAFE", adoption: "#D1FAE5", emergency: "#FFEDD5" };

function timeAgo(iso: string): string {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return "剛剛";
  if (diff < 3600) return `${Math.floor(diff / 60)} 分鐘前`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小時前`;
  return `${Math.floor(diff / 86400)} 天前`;
}

export default function FavoritesScreen() {
  const router = useRouter();
  const [favCases, setFavCases] = useState<PetCase[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [all, favIds] = await Promise.all([getCases(), getFavoriteIds()]);
      setFavCases(all.filter((c) => favIds.includes(c.id)));
    } catch {
      // ignore
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const renderItem = ({ item }: { item: PetCase }) => {
    const imgSrc = item.imageBase64
      ? { uri: `data:image/jpeg;base64,${item.imageBase64}` }
      : item.imageUri ? { uri: item.imageUri } : null;

    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => router.push({ pathname: "/case-detail", params: { id: item.id } })}
        activeOpacity={0.8}
      >
        {/* 縮圖 */}
        <View style={styles.thumb}>
          {imgSrc ? (
            <Image source={imgSrc} style={styles.thumbImg} resizeMode="cover" />
          ) : (
            <View style={[styles.thumbPlaceholder, { backgroundColor: TYPE_BG[item.type] }]}>
              <Text style={styles.thumbEmoji}>
                {item.type === "lost" ? "🐾" : item.type === "found" ? "🤝" : item.type === "emergency" ? "🚨" : "💗"}
              </Text>
              <Text style={[styles.thumbType, { color: TYPE_COLOR[item.type] }]}>
                {TYPE_LABEL[item.type]}
              </Text>
            </View>
          )}
        </View>

        {/* 內容 */}
        <View style={styles.cardBody}>
          <View style={styles.cardTop}>
            <View style={styles.badgeRow}>
              <View style={[styles.badge, { backgroundColor: TYPE_BG[item.type] }]}>
                <Text style={[styles.badgeText, { color: TYPE_COLOR[item.type] }]}>{TYPE_LABEL[item.type]}</Text>
              </View>
              {item.resolved && (
                <View style={styles.resolvedBadge}>
                  <Text style={styles.resolvedBadgeText}>✓ 已解決</Text>
                </View>
              )}
            </View>
            <Text style={styles.time}>{timeAgo(item.createdAt)}</Text>
          </View>
          <Text style={styles.name} numberOfLines={1}>{item.petName || "未命名"}</Text>
          <Text style={styles.breed} numberOfLines={1}>
            {[item.petType, item.breed].filter(Boolean).join(" · ") || "未填寫品種"}
          </Text>
          {item.description ? (
            <Text style={styles.desc} numberOfLines={2}>{item.description}</Text>
          ) : null}
          <View style={styles.footer}>
            <IconSymbol name="location.fill" size={12} color="#6B7280" />
            <Text style={styles.footerText} numberOfLines={1}>{item.location || "未填寫地點"}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenContainer containerClassName="bg-[#1E40AF]" edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>我的收藏</Text>
        <Text style={styles.headerSub}>已收藏 {favCases.length} 筆案件</Text>
      </View>

      <FlatList
        data={favCases}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        style={styles.list}
        contentContainerStyle={styles.listContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#2563EB" />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>💗</Text>
            <Text style={styles.emptyTitle}>尚無收藏案件</Text>
            <Text style={styles.emptySub}>瀏覽案件時點擊愛心圖示即可收藏</Text>
          </View>
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { backgroundColor: "#1E40AF", paddingHorizontal: 16, paddingBottom: 14, flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end" },
  headerTitle: { fontSize: 22, fontWeight: "700", color: "#fff" },
  headerSub: { fontSize: 13, color: "#BFDBFE" },
  list: { backgroundColor: "#F0F4FF" },
  listContent: { padding: 16, paddingBottom: 100 },
  card: { backgroundColor: "#fff", borderRadius: 14, marginBottom: 12, flexDirection: "row", overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
  thumb: { width: 110, height: 120 },
  thumbImg: { width: 110, height: 120 },
  thumbPlaceholder: { width: 110, height: 120, justifyContent: "center", alignItems: "center", gap: 4 },
  thumbEmoji: { fontSize: 28 },
  thumbType: { fontSize: 11, fontWeight: "700" },
  cardBody: { flex: 1, padding: 12 },
  cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 6 },
  badge: { borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  badgeText: { fontSize: 11, fontWeight: "700" },
  time: { fontSize: 11, color: "#9CA3AF" },
  name: { fontSize: 16, fontWeight: "700", color: "#111827", marginBottom: 2 },
  breed: { fontSize: 12, color: "#6B7280", marginBottom: 4 },
  desc: { fontSize: 12, color: "#374151", lineHeight: 17, marginBottom: 6 },
  footer: { flexDirection: "row", alignItems: "center", gap: 4 },
  footerText: { fontSize: 11, color: "#6B7280", flex: 1 },
  empty: { alignItems: "center", paddingTop: 80, gap: 10 },
  emptyIcon: { fontSize: 56 },
  emptyTitle: { fontSize: 18, fontWeight: "700", color: "#1E293B" },
  emptySub: { fontSize: 14, color: "#64748B", textAlign: "center", paddingHorizontal: 32, lineHeight: 20 },
  badgeRow: { flexDirection: "row", gap: 4 },
  resolvedBadge: { borderRadius: 6, paddingHorizontal: 7, paddingVertical: 2, backgroundColor: "#D1FAE5" },
  resolvedBadgeText: { fontSize: 10, fontWeight: "700", color: "#059669" },
});
