import React, { useState } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  ScrollView,
  Switch,
  Alert,
} from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";

interface SettingItemProps {
  icon: string;
  iconColor: string;
  iconBg: string;
  title: string;
  subtitle?: string;
  onPress?: () => void;
  rightElement?: React.ReactNode;
}

function SettingItem({ icon, iconColor, iconBg, title, subtitle, onPress, rightElement }: SettingItemProps) {
  return (
    <Pressable
      style={({ pressed }) => [styles.settingItem, pressed && onPress && { opacity: 0.7 }]}
      onPress={onPress}
    >
      <View style={[styles.settingIcon, { backgroundColor: iconBg }]}>
        <IconSymbol name={icon as any} size={18} color={iconColor} />
      </View>
      <View style={styles.settingContent}>
        <Text style={styles.settingTitle}>{title}</Text>
        {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
      </View>
      {rightElement || (onPress && <IconSymbol name="chevron.right" size={16} color="#CBD5E1" />)}
    </Pressable>
  );
}

export default function SettingsScreen() {
  const [pushNotif, setPushNotif] = useState(true);
  const [urgentNotif, setUrgentNotif] = useState(true);
  const [locationNotif, setLocationNotif] = useState(false);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>設定</Text>
      </View>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Profile Card */}
        <View style={styles.profileCard}>
          <View style={styles.profileAvatar}>
            <Text style={styles.profileEmoji}>🐾</Text>
          </View>
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>寵物協尋用戶</Text>
            <Text style={styles.profileSub}>幫助毛孩回家</Text>
          </View>
          <Pressable
            style={styles.editBtn}
            onPress={() => Alert.alert("編輯個人資料", "功能即將推出")}
          >
            <Text style={styles.editBtnText}>編輯</Text>
          </Pressable>
        </View>

        {/* Notification Settings */}
        <View style={styles.sectionGroup}>
          <Text style={styles.groupTitle}>通知設定</Text>
          <View style={styles.card}>
            <SettingItem
              icon="bell.fill"
              iconColor="#1A56DB"
              iconBg="#EFF6FF"
              title="推播通知"
              subtitle="接收新案件通知"
              rightElement={
                <Switch
                  value={pushNotif}
                  onValueChange={setPushNotif}
                  trackColor={{ false: "#CBD5E1", true: "#93C5FD" }}
                  thumbColor={pushNotif ? "#1A56DB" : "#FFFFFF"}
                />
              }
            />
            <View style={styles.divider} />
            <SettingItem
              icon="exclamationmark.triangle.fill"
              iconColor="#DC2626"
              iconBg="#FEE2E2"
              title="緊急案件通知"
              subtitle="優先接收緊急協尋"
              rightElement={
                <Switch
                  value={urgentNotif}
                  onValueChange={setUrgentNotif}
                  trackColor={{ false: "#CBD5E1", true: "#FCA5A5" }}
                  thumbColor={urgentNotif ? "#DC2626" : "#FFFFFF"}
                />
              }
            />
            <View style={styles.divider} />
            <SettingItem
              icon="location.fill"
              iconColor="#059669"
              iconBg="#D1FAE5"
              title="附近案件通知"
              subtitle="根據您的位置推送"
              rightElement={
                <Switch
                  value={locationNotif}
                  onValueChange={setLocationNotif}
                  trackColor={{ false: "#CBD5E1", true: "#6EE7B7" }}
                  thumbColor={locationNotif ? "#059669" : "#FFFFFF"}
                />
              }
            />
          </View>
        </View>

        {/* App Settings */}
        <View style={styles.sectionGroup}>
          <Text style={styles.groupTitle}>應用程式</Text>
          <View style={styles.card}>
            <SettingItem
              icon="map.fill"
              iconColor="#7C3AED"
              iconBg="#EDE9FE"
              title="地圖設定"
              subtitle="設定搜尋範圍"
              onPress={() => Alert.alert("地圖設定", "功能即將推出")}
            />
            <View style={styles.divider} />
            <SettingItem
              icon="pawprint.fill"
              iconColor="#D97706"
              iconBg="#FEF3C7"
              title="我的寵物資料"
              subtitle="管理您的寵物資訊"
              onPress={() => Alert.alert("寵物資料", "功能即將推出")}
            />
            <View style={styles.divider} />
            <SettingItem
              icon="chart.bar.fill"
              iconColor="#0891B2"
              iconBg="#CFFAFE"
              title="使用統計"
              subtitle="查看您的協尋記錄"
              onPress={() => Alert.alert("使用統計", "功能即將推出")}
            />
          </View>
        </View>

        {/* About */}
        <View style={styles.sectionGroup}>
          <Text style={styles.groupTitle}>關於</Text>
          <View style={styles.card}>
            <SettingItem
              icon="info.circle.fill"
              iconColor="#1A56DB"
              iconBg="#EFF6FF"
              title="關於寵物協尋"
              subtitle="版本 1.0.0"
              onPress={() => Alert.alert("寵物協尋", "幫助走失的毛孩找到回家的路\n版本 1.0.0")}
            />
            <View style={styles.divider} />
            <SettingItem
              icon="star.fill"
              iconColor="#F59E0B"
              iconBg="#FEF3C7"
              title="評分應用程式"
              onPress={() => Alert.alert("評分", "感謝您的支持！")}
            />
            <View style={styles.divider} />
            <SettingItem
              icon="square.and.arrow.up"
              iconColor="#64748B"
              iconBg="#F1F5F9"
              title="分享給朋友"
              onPress={() => Alert.alert("分享", "分享功能即將推出")}
            />
          </View>
        </View>

        {/* Stats Summary */}
        <View style={styles.statsCard}>
          <Text style={styles.statsTitle}>🐾 協尋統計</Text>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statNum}>128</Text>
              <Text style={styles.statLabel}>已協助案件</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statNum}>42</Text>
              <Text style={styles.statLabel}>成功找回</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statNum}>33%</Text>
              <Text style={styles.statLabel}>成功率</Text>
            </View>
          </View>
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F0F4FF",
  },
  header: {
    backgroundColor: "#1A56DB",
    paddingTop: 52,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  profileCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
    shadowColor: "#1A56DB",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
    gap: 12,
  },
  profileAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "#EFF6FF",
    alignItems: "center",
    justifyContent: "center",
  },
  profileEmoji: {
    fontSize: 28,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1E293B",
  },
  profileSub: {
    fontSize: 13,
    color: "#64748B",
    marginTop: 2,
  },
  editBtn: {
    backgroundColor: "#EFF6FF",
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#BFDBFE",
  },
  editBtnText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#1A56DB",
  },
  sectionGroup: {
    marginBottom: 20,
  },
  groupTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#64748B",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: 8,
    paddingHorizontal: 4,
  },
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    overflow: "hidden",
    shadowColor: "#1A56DB",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  settingIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 15,
    fontWeight: "600",
    color: "#1E293B",
  },
  settingSubtitle: {
    fontSize: 12,
    color: "#94A3B8",
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: "#F1F5F9",
    marginLeft: 62,
  },
  statsCard: {
    backgroundColor: "#1A56DB",
    borderRadius: 16,
    padding: 16,
    marginBottom: 8,
  },
  statsTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: "#FFFFFF",
    marginBottom: 14,
  },
  statsRow: {
    flexDirection: "row",
  },
  statItem: {
    flex: 1,
    alignItems: "center",
    gap: 4,
  },
  statNum: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  statLabel: {
    fontSize: 11,
    color: "rgba(255,255,255,0.75)",
  },
  statDivider: {
    width: 1,
    backgroundColor: "rgba(255,255,255,0.2)",
    marginVertical: 4,
  },
});
