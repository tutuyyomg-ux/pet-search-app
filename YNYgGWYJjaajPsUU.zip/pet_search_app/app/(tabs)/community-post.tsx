import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  ActivityIndicator,
  StyleSheet,
  Platform,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as ImageManipulator from "expo-image-manipulator";
import * as Location from "expo-location";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

/**
 * Firestore Schema (posts collection):
 * {
 *   text: string,            // 貼文內容
 *   imageBase64: string,     // 壓縮後的 Base64 圖片（可為空字串）
 *   location: {
 *     latitude: number,
 *     longitude: number,
 *     address: string,       // 反向地理編碼地址
 *   } | null,
 *   petType: string,         // 寵物類型（可選）
 *   caseType: string,        // 案件類型：lost / found / adopt
 *   createdAt: Timestamp,    // Firestore serverTimestamp
 *   authorName: string,      // 發布者名稱（暫時匿名）
 * }
 */

type CaseType = "lost" | "found" | "adopt";

interface LocationData {
  latitude: number;
  longitude: number;
  address: string;
}

const CASE_TYPES: { key: CaseType; label: string; color: string }[] = [
  { key: "lost", label: "遺失協尋", color: "#EF4444" },
  { key: "found", label: "拾獲通報", color: "#3B82F6" },
  { key: "adopt", label: "送養認養", color: "#22C55E" },
];

export default function CommunityPostScreen() {
  const colors = useColors();
  const [text, setText] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [locationData, setLocationData] = useState<LocationData | null>(null);
  const [caseType, setCaseType] = useState<CaseType>("lost");
  const [petType, setPetType] = useState("");
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 選取並壓縮圖片（壓縮至 600px 寬、品質 0.6，確保 Firestore 文件大小限制 1MB 內）
  const handlePickImage = useCallback(async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("需要相簿權限", "請在設定中允許存取相簿");
        return;
      }

      if (Platform.OS === "web") {
        // Web 平台：直接用 base64
        const result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          allowsEditing: true,
          aspect: [4, 3],
          quality: 0.6,
          base64: true,
        });
        if (!result.canceled && result.assets[0]) {
          const asset = result.assets[0];
          if (asset.base64) {
            setImageBase64(asset.base64);
            setSelectedImage(`data:image/jpeg;base64,${asset.base64}`);
          }
        }
        return;
      }

      // 原生平台：先選圖再壓縮
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
        base64: false,
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];

        // 壓縮：縮放至最大寬度 600px，品質 0.6，輸出 base64
        const manipResult = await ImageManipulator.manipulateAsync(
          asset.uri,
          [{ resize: { width: 600 } }],
          {
            compress: 0.6,
            format: ImageManipulator.SaveFormat.JPEG,
            base64: true,
          }
        );

        setSelectedImage(manipResult.uri);
        setImageBase64(manipResult.base64 ?? null);
      }
    } catch (err) {
      console.error("圖片選取失敗:", err);
      Alert.alert("錯誤", "圖片選取失敗，請重試");
    }
  }, []);

  // 取得 GPS 定位與反向地理編碼
  const handleGetLocation = useCallback(async () => {
    try {
      setIsLoadingLocation(true);

      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("需要定位權限", "請在設定中允許存取位置");
        setIsLoadingLocation(false);
        return;
      }

      const position = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const { latitude, longitude } = position.coords;

      // 反向地理編碼取得地址
      let address = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
      try {
        const geocode = await Location.reverseGeocodeAsync({ latitude, longitude });
        if (geocode.length > 0) {
          const g = geocode[0];
          const parts = [g.district, g.city, g.region].filter(Boolean);
          if (parts.length > 0) {
            address = parts.join(", ");
          } else if (g.formattedAddress) {
            address = g.formattedAddress;
          }
        }
      } catch {
        // 反向地理編碼失敗時使用座標
      }

      setLocationData({ latitude, longitude, address });
    } catch (err) {
      console.error("定位失敗:", err);
      Alert.alert("定位失敗", "無法取得目前位置，請確認定位功能已開啟");
    } finally {
      setIsLoadingLocation(false);
    }
  }, []);

  // 發布貼文（Base64 圖片直接存入 Firestore）
  const handleSubmit = useCallback(async () => {
    if (!text.trim()) {
      Alert.alert("請填寫貼文內容", "請描述寵物的詳細資訊");
      return;
    }

    try {
      setIsSubmitting(true);

      // 直接將 base64 存入 Firestore（不需要 Storage）
      await addDoc(collection(db, "posts"), {
        text: text.trim(),
        imageBase64: imageBase64 ?? "",
        location: locationData ?? null,
        caseType,
        petType: petType.trim(),
        authorName: "匿名用戶",
        createdAt: serverTimestamp(),
      });

      Alert.alert("發布成功！", "您的貼文已成功發布到社群", [
        {
          text: "確定",
          onPress: () => {
            setText("");
            setSelectedImage(null);
            setImageBase64(null);
            setLocationData(null);
            setPetType("");
            setCaseType("lost");
          },
        },
      ]);
    } catch (err) {
      console.error("發布失敗:", err);
      Alert.alert("發布失敗", "請確認網路連線後重試");
    } finally {
      setIsSubmitting(false);
    }
  }, [text, imageBase64, locationData, caseType, petType]);

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* 頂部標題 */}
        <View style={[styles.header, { backgroundColor: "#1A56DB" }]}>
          <Text style={styles.headerTitle}>發布社群貼文</Text>
          <Text style={styles.headerSubtitle}>分享寵物協尋資訊給更多人</Text>
        </View>

        <View style={styles.body}>
          {/* 案件類型選擇 */}
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>案件類型</Text>
          <View style={styles.caseTypeRow}>
            {CASE_TYPES.map((ct) => (
              <TouchableOpacity
                key={ct.key}
                style={[
                  styles.caseTypeBtn,
                  {
                    backgroundColor: caseType === ct.key ? ct.color : colors.surface,
                    borderColor: ct.color,
                  },
                ]}
                onPress={() => setCaseType(ct.key)}
              >
                <Text
                  style={[
                    styles.caseTypeBtnText,
                    { color: caseType === ct.key ? "#fff" : ct.color },
                  ]}
                >
                  {ct.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* 寵物類型 */}
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>寵物類型（選填）</Text>
          <TextInput
            style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface }]}
            placeholder="例：柴犬、橘貓、米克斯..."
            placeholderTextColor={colors.muted}
            value={petType}
            onChangeText={setPetType}
          />

          {/* 貼文內容 */}
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>
            貼文內容 <Text style={{ color: "#EF4444" }}>*</Text>
          </Text>
          <TextInput
            style={[
              styles.textArea,
              { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
            ]}
            placeholder="請描述寵物的詳細資訊、遺失/拾獲地點、特徵、聯絡方式等..."
            placeholderTextColor={colors.muted}
            value={text}
            onChangeText={setText}
            multiline
            numberOfLines={5}
            maxLength={500}
            textAlignVertical="top"
          />
          <Text style={[styles.charCount, { color: colors.muted }]}>{text.length}/500 字</Text>

          {/* 圖片上傳區 */}
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>寵物照片（選填）</Text>
          <TouchableOpacity
            style={[styles.imagePickerBox, { borderColor: colors.border, backgroundColor: colors.surface }]}
            onPress={handlePickImage}
          >
            {selectedImage ? (
              <View style={styles.imagePreviewContainer}>
                <Image source={{ uri: selectedImage }} style={styles.imagePreview} resizeMode="cover" />
                <View style={styles.imageOverlay}>
                  <IconSymbol name="pencil" size={20} color="#fff" />
                  <Text style={styles.imageOverlayText}>更換照片</Text>
                </View>
              </View>
            ) : (
              <View style={styles.imagePlaceholder}>
                <IconSymbol name="camera.fill" size={32} color={colors.muted} />
                <Text style={[styles.imagePlaceholderText, { color: colors.muted }]}>
                  點擊選擇照片
                </Text>
                <Text style={[styles.imagePlaceholderHint, { color: colors.muted }]}>
                  支援 JPG、PNG，自動壓縮至 600px
                </Text>
              </View>
            )}
          </TouchableOpacity>

          {/* GPS 定位 */}
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>定位資訊（選填）</Text>
          <TouchableOpacity
            style={[
              styles.locationBtn,
              {
                backgroundColor: locationData ? "#EFF6FF" : colors.surface,
                borderColor: locationData ? "#3B82F6" : colors.border,
              },
            ]}
            onPress={handleGetLocation}
            disabled={isLoadingLocation}
          >
            {isLoadingLocation ? (
              <ActivityIndicator size="small" color="#3B82F6" />
            ) : (
              <IconSymbol
                name="location.fill"
                size={20}
                color={locationData ? "#3B82F6" : colors.muted}
              />
            )}
            <View style={styles.locationTextContainer}>
              {locationData ? (
                <>
                  <Text style={[styles.locationAddress, { color: "#1A56DB" }]}>
                    {locationData.address}
                  </Text>
                  <Text style={styles.locationCoords}>
                    {locationData.latitude.toFixed(5)}, {locationData.longitude.toFixed(5)}
                  </Text>
                </>
              ) : (
                <Text style={[styles.locationPlaceholder, { color: colors.muted }]}>
                  {isLoadingLocation ? "正在取得位置..." : "點擊自動取得目前位置"}
                </Text>
              )}
            </View>
            {locationData && (
              <TouchableOpacity
                onPress={() => setLocationData(null)}
                style={styles.locationClearBtn}
              >
                <IconSymbol name="xmark.circle.fill" size={18} color={colors.muted} />
              </TouchableOpacity>
            )}
          </TouchableOpacity>

          {/* 發布按鈕 */}
          <TouchableOpacity
            style={[styles.submitBtn, { opacity: isSubmitting ? 0.7 : 1 }]}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <>
                <IconSymbol name="paperplane.fill" size={20} color="#fff" />
                <Text style={styles.submitBtnText}>發布貼文</Text>
              </>
            )}
          </TouchableOpacity>

          {/* 提示說明 */}
          <View style={[styles.notice, { backgroundColor: "#FFF7ED", borderColor: "#F59E0B" }]}>
            <IconSymbol name="exclamationmark.triangle.fill" size={16} color="#F59E0B" />
            <Text style={[styles.noticeText, { color: "#92400E" }]}>
              請確保提供真實、準確的資訊。虛假資訊可能導致帳號被停用。
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1 },
  scrollContent: { paddingBottom: 32 },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.85)",
  },
  body: {
    padding: 16,
    gap: 8,
  },
  sectionLabel: {
    fontSize: 15,
    fontWeight: "600",
    marginTop: 12,
    marginBottom: 6,
  },
  caseTypeRow: {
    flexDirection: "row",
    gap: 8,
  },
  caseTypeBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1.5,
    alignItems: "center",
  },
  caseTypeBtnText: {
    fontSize: 13,
    fontWeight: "600",
  },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
  },
  textArea: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    minHeight: 120,
  },
  charCount: {
    fontSize: 12,
    textAlign: "right",
    marginTop: 4,
  },
  imagePickerBox: {
    borderWidth: 1.5,
    borderStyle: "dashed",
    borderRadius: 12,
    overflow: "hidden",
    minHeight: 140,
    justifyContent: "center",
    alignItems: "center",
  },
  imagePreviewContainer: {
    width: "100%",
    height: 200,
    position: "relative",
  },
  imagePreview: {
    width: "100%",
    height: "100%",
  },
  imageOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "rgba(0,0,0,0.5)",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
    gap: 6,
  },
  imageOverlayText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
  imagePlaceholder: {
    alignItems: "center",
    padding: 24,
    gap: 8,
  },
  imagePlaceholderText: {
    fontSize: 15,
    fontWeight: "500",
  },
  imagePlaceholderHint: {
    fontSize: 12,
  },
  locationBtn: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 10,
  },
  locationTextContainer: {
    flex: 1,
  },
  locationAddress: {
    fontSize: 14,
    fontWeight: "600",
  },
  locationCoords: {
    fontSize: 11,
    color: "#6B7280",
    marginTop: 2,
  },
  locationPlaceholder: {
    fontSize: 14,
  },
  locationClearBtn: {
    padding: 4,
  },
  submitBtn: {
    backgroundColor: "#1A56DB",
    borderRadius: 12,
    paddingVertical: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginTop: 16,
  },
  submitBtnText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "700",
  },
  notice: {
    flexDirection: "row",
    alignItems: "flex-start",
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    gap: 8,
    marginTop: 8,
  },
  noticeText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 18,
  },
});
