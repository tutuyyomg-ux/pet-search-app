import { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  FlatList,
  StyleSheet,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { getCases, getStats, type PetCase, type CaseType } from "@/lib/firestore-cases";
import { Image } from "react-native";
import { useFocusEffect } from "@react-navigation/native";

const TYPE_LABEL: Record<CaseType, string> = { lost: "遺失", found: "拾獲", adoption: "認養", emergency: "緊急救護" };
const TYPE_COLOR: Record<CaseType, string> = { lost: "#EF4444", found: "#3B82F6", adoption: "#10B981", emergency: "#F97316" };
const TYPE_BG: Record<CaseType, string> = { lost: "#FEE2E2", found: "#DBEAFE", adoption: "#D1FAE5", emergency: "#FFEDD5" };

function timeAgo(iso: string): string {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return "剛剛";
  if (diff < 3600) return `${Math.floor(diff / 60)} 分鐘前`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小時前`;
  return `${Math.floor(diff / 86400)} 天前`;
}

const ADS = [
  { id: "ad1", title: "寵物保險特惠", sub: "首月保費 0 元，守護毛孩健康", tag: "廣告", color: "#EFF6FF" },
  { id: "ad2", title: "寵物用品優惠", sub: "線上購物滿 500 元免運費", tag: "廣告", color: "#FFF7ED" },
  { id: "ad3", title: "在此刊登廣告", sub: "觸及數千名寵物愛好者", tag: "合作", color: "#F0FDF4" },
];

export default function HomeScreen() {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [cases, setCases] = useState<PetCase[]>([]);
  const [stats, setStats] = useState({ lost: 0, found: 0, adoption: 0, emergency: 0, total: 0 });
  const [bannerIndex, setBannerIndex] = useState(0);

  const load = useCallback(async () => {
    const [c, s] = await Promise.all([getCases(), getStats()]);
    setCases(c.slice(0, 6));
    setStats(s);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  useEffect(() => {
    const t = setInterval(() => setBannerIndex((i) => (i + 1) % 3), 3000);
    return () => clearInterval(t);
  }, []);

  const filtered = search.trim()
    ? cases.filter(
        (c) =>
          c.petName.includes(search) ||
          c.petType.includes(search) ||
          c.breed.includes(search) ||
          c.location.includes(search)
      )
    : cases;

  const BANNERS = [
    { title: "走失的毛孩需要你", sub: "一起幫助牠們找到回家的路", bg: "#1E40AF" },
    { title: "拾獲寵物請通報", sub: "讓失主盡快找回心愛的寵物", bg: "#1D4ED8" },
    { title: "送養資訊公告", sub: "給毛孩一個溫暖的新家", bg: "#2563EB" },
  ];

  return (
    <ScreenContainer containerClassName="bg-[#1E40AF]" edges={["top", "left", "right"]}>
      {/* 頂部藍色 Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>寵物協尋</Text>
          <Text style={styles.headerSub}>幫助毛孩找到回家的路</Text>
        </View>
        <TouchableOpacity style={styles.bellBtn}>
          <IconSymbol name="bell.fill" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* 搜尋欄 */}
      <View style={styles.searchRow}>
        <View style={styles.searchBox}>
          <IconSymbol name="magnifyingglass" size={18} color="#6B7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="搜尋寵物品種、地點..."
            placeholderTextColor="#9CA3AF"
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch("")}>
              <IconSymbol name="xmark" size={16} color="#9CA3AF" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <ScrollView style={{ flex: 1, backgroundColor: "#F0F4FF" }} showsVerticalScrollIndicator={false}>
        {/* 橫幅輪播 */}
        <View style={[styles.banner, { backgroundColor: BANNERS[bannerIndex].bg }]}>
          <View>
            <Text style={styles.bannerTitle}>{BANNERS[bannerIndex].title}</Text>
            <Text style={styles.bannerSub}>{BANNERS[bannerIndex].sub}</Text>
          </View>
          <View style={styles.bannerDots}>
            {BANNERS.map((_, i) => (
              <View key={i} style={[styles.dot, i === bannerIndex && styles.dotActive]} />
            ))}
          </View>
        </View>

        {/* 快速分類 */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>快速分類</Text>
          <View style={styles.catRow}>
            {(["lost", "found", "adoption", "emergency"] as CaseType[]).map((t) => (
              <TouchableOpacity
                key={t}
                style={[styles.catCard, { backgroundColor: TYPE_BG[t] }]}
                onPress={() => router.push({ pathname: "/(tabs)/cases", params: { type: t } })}
                activeOpacity={0.75}
              >
                <Text style={styles.catIcon}>{t === "lost" ? "🐾" : t === "found" ? "🤝" : t === "emergency" ? "🚨" : "💗"}</Text>
                <Text style={[styles.catLabel, { color: TYPE_COLOR[t] }]}>
                  {t === "lost" ? "遺失協尋" : t === "found" ? "拾獲通報" : t === "emergency" ? "緊急救護" : "送養認養"}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* 廣告橫幅 */}
        <View style={styles.section}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {ADS.map((ad) => (
              <View key={ad.id} style={[styles.adCard, { backgroundColor: ad.color }]}>
                <Text style={styles.adTag}>{ad.tag}</Text>
                <Text style={styles.adTitle}>{ad.title}</Text>
                <Text style={styles.adSub}>{ad.sub}</Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* 統計 */}
        <View style={styles.statsRow}>
          {[
            { label: "遺失案件", value: stats.lost, color: "#EF4444" },
            { label: "拾獲通報", value: stats.found, color: "#3B82F6" },
            { label: "待認養", value: stats.adoption, color: "#10B981" },
            { label: "緊急救護", value: stats.emergency, color: "#F97316" },
          ].map((s) => (
            <View key={s.label} style={styles.statItem}>
              <Text style={[styles.statNum, { color: s.color }]}>{s.value}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* 最新案件 */}
        <View style={styles.section}>
          <View style={styles.sectionRow}>
            <Text style={styles.sectionTitle}>最新案件</Text>
            <TouchableOpacity onPress={() => router.push("/(tabs)/cases")}>
              <Text style={styles.seeAll}>查看全部</Text>
            </TouchableOpacity>
          </View>

          {filtered.length === 0 ? (
            <View style={styles.empty}>
              <Text style={styles.emptyIcon}>🐾</Text>
              <Text style={styles.emptyText}>
                {search ? "找不到符合的案件" : "目前還沒有案件，成為第一個發布的人！"}
              </Text>
            </View>
          ) : (
            filtered.map((item) => {
              const imgSrc = item.imageBase64
                ? { uri: `data:image/jpeg;base64,${item.imageBase64}` }
                : item.imageUri ? { uri: item.imageUri } : null;
              return (
                <TouchableOpacity
                  key={item.id}
                  style={styles.card}
                  onPress={() => router.push({ pathname: "/case-detail", params: { id: item.id } })}
                  activeOpacity={0.8}
                >
                  {/* 縮圖 */}
                  <View style={styles.cardThumb}>
                    {imgSrc ? (
                      <Image source={imgSrc} style={styles.cardThumbImg} resizeMode="cover" />
                    ) : (
                      <View style={[styles.cardThumbPlaceholder, { backgroundColor: TYPE_BG[item.type] }]}>
                        <Text style={styles.cardThumbEmoji}>
                          {item.type === "lost" ? "🐾" : item.type === "found" ? "🤝" : item.type === "emergency" ? "🚨" : "💗"}
                        </Text>
                      </View>
                    )}
                  </View>
                  <View style={styles.cardBody}>
                    <View style={styles.cardLeft}>
                      <View style={[styles.typeBadge, { backgroundColor: TYPE_BG[item.type] }]}>
                        <Text style={[styles.typeBadgeText, { color: TYPE_COLOR[item.type] }]}>
                          {TYPE_LABEL[item.type]}
                        </Text>
                      </View>
                      {item.isUrgent && (
                        <View style={styles.urgentBadge}>
                          <Text style={styles.urgentText}>緊急</Text>
                        </View>
                      )}
                      {item.resolved && (
                        <View style={styles.resolvedBadge}>
                          <Text style={styles.resolvedBadgeText}>✓ 已解決</Text>
                        </View>
                      )}
                    </View>
                    <Text style={styles.cardName}>{item.petName || "未命名"}</Text>
                    <Text style={styles.cardBreed}>{[item.petType, item.breed].filter(Boolean).join(" · ") || "未填寫"}</Text>
                    <View style={styles.cardMeta}>
                      <IconSymbol name="location.fill" size={12} color="#6B7280" />
                      <Text style={styles.cardMetaText} numberOfLines={1}>{item.location || "未填寫地點"}</Text>
                      <IconSymbol name="clock.fill" size={12} color="#6B7280" />
                      <Text style={styles.cardMetaText}>{timeAgo(item.createdAt)}</Text>
                    </View>
                  </View>
                  <IconSymbol name="chevron.right" size={16} color="#9CA3AF" />
                </TouchableOpacity>
              );
            })
          )}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingBottom: 12, backgroundColor: "#1E40AF" },
  headerTitle: { fontSize: 22, fontWeight: "700", color: "#fff" },
  headerSub: { fontSize: 12, color: "#BFDBFE", marginTop: 2 },
  bellBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  searchRow: { backgroundColor: "#1E40AF", paddingHorizontal: 16, paddingBottom: 14 },
  searchBox: { flexDirection: "row", alignItems: "center", backgroundColor: "#fff", borderRadius: 24, paddingHorizontal: 14, paddingVertical: Platform.OS === "ios" ? 10 : 6, gap: 8 },
  searchInput: { flex: 1, fontSize: 14, color: "#111827" },
  banner: { margin: 16, borderRadius: 16, padding: 20, minHeight: 90 },
  bannerTitle: { fontSize: 18, fontWeight: "700", color: "#fff" },
  bannerSub: { fontSize: 13, color: "#BFDBFE", marginTop: 4 },
  bannerDots: { flexDirection: "row", gap: 6, marginTop: 12 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "rgba(255,255,255,0.4)" },
  dotActive: { backgroundColor: "#fff", width: 16 },
  section: { paddingHorizontal: 16, marginBottom: 8 },
  sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  sectionTitle: { fontSize: 16, fontWeight: "700", color: "#111827", marginBottom: 10 },
  seeAll: { fontSize: 13, color: "#2563EB" },
  catRow: { flexDirection: "row", gap: 10 },
  catCard: { flex: 1, borderRadius: 12, padding: 14, alignItems: "center", gap: 6 },
  catIcon: { fontSize: 24 },
  catLabel: { fontSize: 12, fontWeight: "600" },
  adCard: { width: 160, borderRadius: 12, padding: 14, marginRight: 10 },
  adTag: { fontSize: 10, color: "#6B7280", marginBottom: 4 },
  adTitle: { fontSize: 14, fontWeight: "700", color: "#111827" },
  adSub: { fontSize: 11, color: "#6B7280", marginTop: 4 },
  statsRow: { flexDirection: "row", backgroundColor: "#fff", marginHorizontal: 16, borderRadius: 14, marginBottom: 16, overflow: "hidden" },
  statItem: { flex: 1, alignItems: "center", paddingVertical: 14, borderRightWidth: 0.5, borderRightColor: "#E5E7EB" },
  statNum: { fontSize: 22, fontWeight: "800" },
  statLabel: { fontSize: 11, color: "#6B7280", marginTop: 2 },
  card: { flexDirection: "row", alignItems: "center", backgroundColor: "#fff", borderRadius: 14, marginBottom: 10, overflow: "hidden" },
  cardThumb: { width: 90, height: 90 },
  cardThumbImg: { width: 90, height: 90 },
  cardThumbPlaceholder: { width: 90, height: 90, justifyContent: "center", alignItems: "center" },
  cardThumbEmoji: { fontSize: 26 },
  cardLeft: { flexDirection: "row", gap: 4, marginBottom: 4 },
  cardBody: { flex: 1, padding: 10, gap: 3 },
  typeBadge: { borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  typeBadgeText: { fontSize: 11, fontWeight: "700" },
  urgentBadge: { backgroundColor: "#FEE2E2", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  urgentText: { fontSize: 10, color: "#EF4444", fontWeight: "700" },
  cardName: { fontSize: 15, fontWeight: "700", color: "#111827" },
  cardBreed: { fontSize: 12, color: "#6B7280" },
  cardMeta: { flexDirection: "row", alignItems: "center", gap: 4, flexWrap: "wrap" },
  cardMetaText: { fontSize: 11, color: "#6B7280" },
  empty: { alignItems: "center", paddingVertical: 32 },
  emptyIcon: { fontSize: 40, marginBottom: 10 },
  emptyText: { fontSize: 14, color: "#9CA3AF", textAlign: "center" },
  resolvedBadge: { borderRadius: 6, paddingHorizontal: 7, paddingVertical: 2, backgroundColor: "#D1FAE5" },
  resolvedBadgeText: { fontSize: 10, fontWeight: "700", color: "#059669" },
});
