# 寵物協尋 App TODO

## Phase 1: 初始化與設計
- [x] 初始化專案架構
- [x] 建立設計規劃文件 (design.md)
- [x] 設定藍色主題色彩 (theme.config.js)
- [x] 生成 App Logo
- [x] 更新 app.config.ts

## Phase 2: 首頁與案件列表
- [x] 更新底部 Tab Bar（首頁/案件/上傳/收藏/設定）
- [x] 首頁：頂部搜尋欄（藍色背景）
- [x] 首頁：橫幅輪播（Banner）
- [x] 首頁：快速分類按鈕（遺失/拾獲/認養）
- [x] 首頁：最新案件卡片列表
- [x] 案件列表頁：篩選 Tab（全部/遺失/拾獲/認養）
- [x] 案件列表頁：搜尋功能
- [x] 案件列表頁：案件卡片

## Phase 3: 案件上傳與詳情
- [x] 案件上傳頁：選擇案件類型
- [x] 案件上傳頁：填寫描述（500字限制）
- [x] 案件上傳頁：圖片選擇
- [x] 案件上傳頁：發布案件按鈕
- [x] 案件詳情頁：完整資訊顯示
- [x] 案件詳情頁：聯絡按鈕
- [x] 案件詳情頁：收藏功能

## Phase 4: 其他頁面
- [x] 收藏頁面
- [x] 設定頁面（通知設定、關於）
- [x] 互動效果與動畫

## Phase 5: 後端整合與廣告
- [x] 讀取 server/README.md 了解後端架構
- [x] 設計案件資料庫 Schema（cases 表）
- [x] 實作案件 CRUD API（建立/查詢/刪除）
- [x] 實作圖片上傳 S3 API
- [x] 前端串接案件列表 API（取代假資料）
- [x] 前端串接案件上傳 API（含圖片上傳）
- [x] 前端串接案件詳情 API
- [x] 首頁加入廣告橫幅元件

## Phase 6: Firebase 社群發文功能
- [x] 安裝 Firebase SDK、expo-location、expo-image-manipulator
- [x] 設定 Firebase 配置（firebaseConfig）
- [x] 建立 Firestore posts collection schema
- [x] 實作發布貼文頁面（圖片 Base64、GPS 定位、Firestore 寫入）
- [x] 實作社群貼文列表頁面（從 Firestore 即時讀取）
- [x] 整合至底部導航

## Phase 7: UI 改進與留言功能
- [ ] 移除社群 Tab，更新底部導航
- [ ] 案件列表加入時間篩選（今天/本週/本月）
- [ ] 發布頁面移除強制填寫驗證
- [ ] 案件詳情頁加入 Firestore 留言功能

## Phase 8: 案件卡片與時間篩選改進
- [ ] 案件卡片右上角顯示寵物圖片縮圖
- [ ] 時間篩選改為：本週/本月/三個月/半年/一年/一年以上

## Phase 9: Firestore 同步、行事曆、縮圖改進
- [x] 案件資料從 AsyncStorage 遷移至 Firestore（跨裝置同步）
- [x] 上傳圖片壓縮成 Base64 存入 Firestore
- [x] 行事曆日期選擇器（上傳頁：事發日期）
- [x] 行事曆日期範圍選擇器（搜尋頁：開始日期～結束日期）
- [x] 所有案件卡片無圖片時顯示類型對應 emoji 縮圖佔位符
- [x] 首頁最新案件顯示縮圖
- [x] 收藏頁顯示縮圖
- [x] 案件詳情頁無圖片時顯示類型對應縮圖

## Phase 10: 標記已解決功能
- [x] Firestore PetCase 介面加入 resolved / resolvedAt 欄位
- [x] 新增 resolveCase() 函式更新 Firestore 狀態
- [x] 案件詳情頁加入「標記為已解決」綠色按鈕（含確認 Alert）
- [x] 已解決案件顯示「✓ 已解決」綠色標籤（詳情頁 badge 區）
- [x] 已解決顯示解決日期（詳情頁底部）
- [x] 可取消已解決狀態（按鈕變灰色「取消已解決」）
- [x] 首頁最新案件卡片顯示「✓ 已解決」標籤
- [x] 案件列表卡片顯示「✓ 已解決」標籤
- [x] 收藏頁卡片顯示「✓ 已解決」標籤
